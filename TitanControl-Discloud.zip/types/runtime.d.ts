import type { ArtifactStore, Database } from "../app/server-runtime";

declare global {
  type D1Database = Database;
  type R2Bucket = ArtifactStore;
}

export {};
