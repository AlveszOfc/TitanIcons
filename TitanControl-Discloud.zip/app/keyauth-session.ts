type Product = "full" | "legit";

type KeyAuthPayload = {
  success?: boolean;
  message?: string;
  info?: { username?: string };
};

const KEYAUTH_API_URL = "https://keyauth.win/api/1.3/";
const KEYAUTH_APPS: Record<Product, { name: string; ownerId: string }> = {
  full: { name: "TitanMenuFull", ownerId: "klozNLOhhs" },
  legit: { name: "TitanMenuLegit", ownerId: "klozNLOhhs" },
};

export class AuthorizationError extends Error {
  constructor(message: string, public readonly status = 403) {
    super(message);
    this.name = "AuthorizationError";
  }
}

export async function verifyKeyAuthSession(rawSessionId: unknown, product: Product) {
  const sessionId = String(rawSessionId || "").trim();
  if (!/^[a-zA-Z0-9_-]{8,256}$/.test(sessionId)) {
    throw new AuthorizationError("Sua sessão de licença é inválida. Entre novamente no Loader.");
  }

  const application = KEYAUTH_APPS[product];
  const body = new URLSearchParams({
    type: "check",
    sessionid: sessionId,
    name: application.name,
    ownerid: application.ownerId,
  });
  let response: Response;
  try {
    response = await fetch(KEYAUTH_API_URL, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: body.toString(),
      cache: "no-store",
    });
  } catch {
    throw new AuthorizationError("Não foi possível validar sua licença agora. Tente novamente.", 503);
  }

  const text = await response.text();
  let payload: KeyAuthPayload = {};
  try {
    payload = text ? JSON.parse(text) as KeyAuthPayload : {};
  } catch {
    throw new AuthorizationError("O serviço de licença retornou uma resposta inválida.", 503);
  }
  if (!response.ok || payload.success !== true) {
    throw new AuthorizationError("Sua sessão expirou ou a licença não está mais válida. Entre novamente no Loader.");
  }

  return { username: String(payload.info?.username || "").trim().slice(0, 64) };
}
