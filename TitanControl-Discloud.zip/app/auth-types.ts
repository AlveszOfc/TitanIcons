export type SiteRole = "admin" | "reseller";

export type SiteUser = {
  discordId: string;
  username: string;
  displayName: string;
  avatar: string;
  role: SiteRole;
};
