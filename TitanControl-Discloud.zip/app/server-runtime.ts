import { Pool, types, type PoolClient, type QueryResultRow } from "pg";

types.setTypeParser(20, (value) => Number(value));

export type DatabaseRunResult = {
  success: boolean;
  meta: { changes: number };
};

export type DatabaseAllResult<T> = {
  success: boolean;
  results: T[];
};

type QueryClient = Pool | PoolClient;

function convertSql(source: string) {
  let index = 0;
  let singleQuoted = false;
  let doubleQuoted = false;
  let output = "";

  for (let cursor = 0; cursor < source.length; cursor += 1) {
    const character = source[cursor];
    const previous = source[cursor - 1];
    if (character === "'" && !doubleQuoted && previous !== "\\") singleQuoted = !singleQuoted;
    if (character === '"' && !singleQuoted && previous !== "\\") doubleQuoted = !doubleQuoted;
    if (character === "?" && !singleQuoted && !doubleQuoted) {
      index += 1;
      output += `$${index}`;
    } else {
      output += character;
    }
  }

  return output
    .replace(/\s+COLLATE\s+NOCASE/gi, "")
    .replace(/\bAS\s+([a-z_][a-z0-9_]*[A-Z][a-zA-Z0-9_]*)\b/g, 'AS "$1"');
}

export class DatabaseStatement {
  private parameters: unknown[] = [];

  constructor(private readonly database: Database, private readonly source: string) {}

  bind(...values: unknown[]) {
    this.parameters = values;
    return this;
  }

  async execute(client: QueryClient = this.database.pool) {
    return client.query(convertSql(this.source), this.parameters);
  }

  async first<T = Record<string, unknown>>(): Promise<T | null> {
    const result = await this.execute();
    return (result.rows[0] as T | undefined) || null;
  }

  async all<T = Record<string, unknown>>(): Promise<DatabaseAllResult<T>> {
    const result = await this.execute();
    return { success: true, results: result.rows as T[] };
  }

  async run(): Promise<DatabaseRunResult> {
    const result = await this.execute();
    return { success: true, meta: { changes: result.rowCount || 0 } };
  }
}

export class Database {
  constructor(readonly pool: Pool) {}

  prepare(sql: string) {
    return new DatabaseStatement(this, sql);
  }

  async batch(statements: DatabaseStatement[]) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const results: DatabaseRunResult[] = [];
      for (const statement of statements) {
        const result = await statement.execute(client);
        results.push({ success: true, meta: { changes: result.rowCount || 0 } });
      }
      await client.query("COMMIT");
      return results;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
}

export type ArtifactObject = {
  body: ReadableStream<Uint8Array>;
  arrayBuffer(): Promise<ArrayBuffer>;
};

type ArtifactBody = ReadableStream<Uint8Array> | Blob | ArrayBuffer | Uint8Array;

async function readBody(body: ArtifactBody) {
  if (body instanceof Uint8Array) return body;
  if (body instanceof ArrayBuffer) return new Uint8Array(body);
  return new Uint8Array(await new Response(body).arrayBuffer());
}

export class ArtifactStore {
  private schemaPromise: Promise<void> | null = null;

  constructor(private readonly database: Database) {}

  private ensureSchema() {
    if (!this.schemaPromise) {
      this.schemaPromise = this.database.prepare(`CREATE TABLE IF NOT EXISTS artifact_objects (
        object_key TEXT PRIMARY KEY,
        data BYTEA NOT NULL,
        content_type TEXT NOT NULL DEFAULT 'application/octet-stream',
        size BIGINT NOT NULL,
        updated_at BIGINT NOT NULL
      )`).run().then(() => undefined).catch((error) => {
        this.schemaPromise = null;
        throw error;
      });
    }
    return this.schemaPromise;
  }

  async put(key: string, body: ArtifactBody, options?: { httpMetadata?: { contentType?: string } }) {
    await this.ensureSchema();
    const bytes = await readBody(body);
    await this.database.prepare(`INSERT INTO artifact_objects (object_key, data, content_type, size, updated_at)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(object_key) DO UPDATE SET data = excluded.data, content_type = excluded.content_type,
      size = excluded.size, updated_at = excluded.updated_at`)
      .bind(key, Buffer.from(bytes), options?.httpMetadata?.contentType || "application/octet-stream", bytes.byteLength, Math.floor(Date.now() / 1000))
      .run();
  }

  async get(key: string): Promise<ArtifactObject | null> {
    await this.ensureSchema();
    const row = await this.database.prepare("SELECT data FROM artifact_objects WHERE object_key = ?")
      .bind(key).first<{ data: Buffer }>();
    if (!row) return null;
    const bytes = new Uint8Array(row.data);
    return {
      body: new ReadableStream<Uint8Array>({
        start(controller) {
          controller.enqueue(bytes);
          controller.close();
        },
      }),
      async arrayBuffer() {
        return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
      },
    };
  }

  async delete(key: string) {
    await this.ensureSchema();
    await this.database.prepare("DELETE FROM artifact_objects WHERE object_key = ?").bind(key).run();
  }
}

function createPool() {
  const connectionString = process.env.DATABASE_URL?.trim();
  if (!connectionString) throw new Error("DATABASE_URL ainda nao foi configurada na Discloud.");
  const useSsl = process.env.DATABASE_SSL?.trim().toLowerCase() === "true";
  return new Pool({
    connectionString,
    max: Math.max(2, Math.min(20, Number(process.env.DATABASE_POOL_SIZE) || 10)),
    ssl: useSsl ? { rejectUnauthorized: false } : undefined,
  });
}

let database: Database | null = null;
let artifacts: ArtifactStore | null = null;

function getDatabase() {
  if (!database) database = new Database(createPool());
  return database;
}

function getArtifactStore() {
  if (!artifacts) artifacts = new ArtifactStore(getDatabase());
  return artifacts;
}

type RuntimeEnvironment = Record<string, string | Database | ArtifactStore | undefined> & {
  DB: Database;
  ARTIFACTS: ArtifactStore;
};

export const env = new Proxy({} as RuntimeEnvironment, {
  get(_target, property) {
    if (property === "DB") return getDatabase();
    if (property === "ARTIFACTS") return getArtifactStore();
    if (typeof property === "string") return process.env[property];
    return undefined;
  },
});

export async function checkDatabaseConnection() {
  const result = await getDatabase().pool.query<{ ok: number } & QueryResultRow>("SELECT 1 AS ok");
  return result.rows[0]?.ok === 1;
}
