import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://painel.titanservices.xyz"),
  title: {
    default: "Titan Control",
    template: "%s | Titan Control",
  },
  description: "Gerencie produtos, clientes, licenças e operações da Titan Services.",
  openGraph: {
    title: "Titan Control",
    description: "Seu ecossistema, em um só lugar.",
    type: "website",
    locale: "pt_BR",
    images: [{ url: "/og.png", width: 1792, height: 928, alt: "Titan Control" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Titan Control",
    description: "Seu ecossistema, em um só lugar.",
    images: ["/og.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
