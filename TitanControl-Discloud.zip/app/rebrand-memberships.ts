export type RebrandMembership = {
  id: string;
  rebrandId: string;
  rebrandToken: string;
  username: string;
  usernameKey: string;
  product: "full" | "legit";
  subscription: string;
  licenseExpiry: number;
  hwid: string;
  firstSeen: number;
  lastSeen: number;
};

export type MembershipInput = {
  rebrandId: string;
  username: string;
  product: string;
  subscription?: string;
  licenseExpiry?: number;
  hwid?: string;
};

export async function ensureMembershipSchema(db: D1Database) {
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS rebrand_memberships (
      id TEXT PRIMARY KEY,
      rebrand_id TEXT NOT NULL,
      username TEXT NOT NULL,
      username_key TEXT NOT NULL,
      product TEXT NOT NULL,
      subscription TEXT NOT NULL DEFAULT '',
      license_expiry INTEGER NOT NULL DEFAULT 0,
      hwid TEXT NOT NULL DEFAULT '',
      first_seen INTEGER NOT NULL,
      last_seen INTEGER NOT NULL
    )`),
    db.prepare("CREATE UNIQUE INDEX IF NOT EXISTS rebrand_memberships_account_unique ON rebrand_memberships(product, username_key)"),
    db.prepare("CREATE INDEX IF NOT EXISTS rebrand_memberships_rebrand_idx ON rebrand_memberships(rebrand_id)"),
  ]);
}

export function normalizeProduct(value: unknown): "full" | "legit" {
  return String(value || "").trim().toLowerCase() === "legit" ? "legit" : "full";
}

export function normalizeUsername(value: unknown) {
  return String(value || "").trim().slice(0, 64);
}

export async function sha256(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function findRebrandByToken(db: D1Database, rawToken: string) {
  const token = rawToken.trim();
  if (!token) return null;
  return db.prepare("SELECT id FROM rebrands WHERE token_hash = ? LIMIT 1")
    .bind(await sha256(token))
    .first<{ id: string }>();
}

export async function saveMembership(db: D1Database, input: MembershipInput) {
  await ensureMembershipSchema(db);
  const username = normalizeUsername(input.username);
  if (!input.rebrandId || !username) throw new Error("Rebrand e usuário são obrigatórios.");
  const product = normalizeProduct(input.product);
  const usernameKey = username.toLowerCase();
  const subscription = String(input.subscription || "").trim().slice(0, 64);
  const licenseExpiry = Math.max(0, Math.trunc(Number(input.licenseExpiry) || 0));
  const hwid = String(input.hwid || "").trim().slice(0, 256);
  const now = Math.floor(Date.now() / 1000);

  await db.prepare(`INSERT INTO rebrand_memberships
    (id, rebrand_id, username, username_key, product, subscription, license_expiry, hwid, first_seen, last_seen)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(product, username_key) DO UPDATE SET
      username = excluded.username,
      subscription = CASE WHEN excluded.subscription <> '' THEN excluded.subscription ELSE rebrand_memberships.subscription END,
      license_expiry = CASE WHEN excluded.license_expiry > 0 THEN excluded.license_expiry ELSE rebrand_memberships.license_expiry END,
      hwid = CASE WHEN excluded.hwid <> '' THEN excluded.hwid ELSE rebrand_memberships.hwid END,
      last_seen = excluded.last_seen`)
    .bind(crypto.randomUUID(), input.rebrandId, username, usernameKey, product, subscription, licenseExpiry, hwid, now, now)
    .run();
}

export async function listMemberships(db: D1Database, owner?: string) {
  await ensureMembershipSchema(db);
  const sql = `SELECT m.id, m.rebrand_id AS rebrandId, r.token AS rebrandToken,
    m.username, m.username_key AS usernameKey, m.product, m.subscription,
    m.license_expiry AS licenseExpiry, m.hwid, m.first_seen AS firstSeen, m.last_seen AS lastSeen
    FROM rebrand_memberships m JOIN rebrands r ON r.id = m.rebrand_id
    ${owner ? "WHERE r.created_by = ?" : ""}
    ORDER BY m.last_seen DESC`;
  const result = await db.prepare(sql).bind(...(owner ? [owner] : [])).all<RebrandMembership>();
  return result.results || [];
}
