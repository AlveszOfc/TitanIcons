import { sha256 } from "./rebrand-memberships";
import { AuthorizationError } from "./keyauth-session";

async function ensureRateLimitSchema(db: D1Database) {
  await db.prepare(`CREATE TABLE IF NOT EXISTS artifact_authorization_limits (
    bucket TEXT PRIMARY KEY,
    window_start INTEGER NOT NULL,
    requests INTEGER NOT NULL DEFAULT 0
  )`).run();
}

async function consumeBucket(db: D1Database, bucket: string, maximum: number, now: number) {
  const cutoff = now - 60;
  await db.prepare(`INSERT INTO artifact_authorization_limits (bucket, window_start, requests)
    VALUES (?, ?, 1)
    ON CONFLICT(bucket) DO UPDATE SET
      requests = CASE WHEN artifact_authorization_limits.window_start <= ? THEN 1 ELSE artifact_authorization_limits.requests + 1 END,
      window_start = CASE WHEN artifact_authorization_limits.window_start <= ? THEN excluded.window_start ELSE artifact_authorization_limits.window_start END`)
    .bind(bucket, now, cutoff, cutoff).run();
  const row = await db.prepare("SELECT requests FROM artifact_authorization_limits WHERE bucket = ?")
    .bind(bucket).first<{ requests: number }>();
  if ((row?.requests || 0) > maximum) throw new AuthorizationError("Muitas tentativas. Aguarde um minuto e tente novamente.", 429);
}

export async function enforceArtifactRateLimit(db: D1Database, request: Request, rebrandToken: string) {
  await ensureRateLimitSchema(db);
  const now = Math.floor(Date.now() / 1000);
  const forwarded = request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for")?.split(",")[0] || "unknown";
  const [ipBucket, tokenBucket] = await Promise.all([
    sha256(`artifact:ip:${forwarded.trim()}`),
    sha256(`artifact:token:${rebrandToken}`),
  ]);
  await consumeBucket(db, ipBucket, 20, now);
  await consumeBucket(db, tokenBucket, 8, now);
  if (Math.random() < 0.05) await db.prepare("DELETE FROM artifact_authorization_limits WHERE window_start < ?").bind(now - 600).run();
}
