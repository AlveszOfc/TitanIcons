import { cookies } from "next/headers";
import { env } from "./server-runtime";
import type { SiteRole, SiteUser } from "./auth-types";

type Runtime = { DB?: D1Database; DISCORD_CLIENT_ID?: string; DISCORD_CLIENT_SECRET?: string; DISCORD_REDIRECT_URI?: string; DISCORD_GUILD_ID?: string; DISCORD_ADMIN_ID?: string };
type StoredUser = SiteUser & { active: number };

const SESSION_COOKIE = "titan_session";
const STATE_COOKIE = "titan_oauth_state";

function runtime() {
  const value = env as unknown as Runtime;
  if (!value.DB) throw new Error("Banco de dados ainda nao foi conectado.");
  return value as Runtime & { DB: D1Database };
}

export function authConfig() {
  const clientId = process.env.DISCORD_CLIENT_ID?.trim();
  const clientSecret = process.env.DISCORD_CLIENT_SECRET?.trim();
  const redirectUri = process.env.DISCORD_REDIRECT_URI?.trim();
  const guildId = process.env.DISCORD_GUILD_ID?.trim();
  const adminId = process.env.DISCORD_ADMIN_ID?.trim();
  const missing = [
    ["DISCORD_CLIENT_ID", clientId],
    ["DISCORD_CLIENT_SECRET", clientSecret],
    ["DISCORD_REDIRECT_URI", redirectUri],
    ["DISCORD_GUILD_ID", guildId],
    ["DISCORD_ADMIN_ID", adminId],
  ].filter(([, value]) => !value).map(([name]) => name);
  if (!clientId || !clientSecret || !redirectUri || !guildId || !adminId) {
    throw new Error(`Login Discord ainda nao foi configurado. Variaveis ausentes: ${missing.join(", ")}.`);
  }
  return { clientId, clientSecret, redirectUri, guildId, adminId };
}

export async function ensureAuthSchema(db = runtime().DB) {
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS web_users (discord_id TEXT PRIMARY KEY, username TEXT NOT NULL, display_name TEXT NOT NULL, avatar TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT 'pending', active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, last_login INTEGER NOT NULL DEFAULT 0)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS web_sessions (token_hash TEXT PRIMARY KEY, discord_id TEXT NOT NULL, expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL)`),
  ]);
}

function randomToken(bytes = 32) {
  const data = new Uint8Array(bytes);
  crypto.getRandomValues(data);
  return Array.from(data, (value) => value.toString(16).padStart(2, "0")).join("");
}

export async function hashToken(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function parseCookies(header: string | null) {
  const result: Record<string, string> = {};
  for (const part of (header || "").split(";")) {
    const index = part.indexOf("=");
    if (index <= 0) continue;
    result[part.slice(0, index).trim()] = decodeURIComponent(part.slice(index + 1).trim());
  }
  return result;
}

export function cookieHeader(name: string, value: string, options: { maxAge?: number; httpOnly?: boolean } = {}) {
  const parts = [`${name}=${encodeURIComponent(value)}`, "Path=/", "SameSite=Lax", "Secure"];
  if (options.maxAge !== undefined) parts.push(`Max-Age=${options.maxAge}`);
  if (options.httpOnly !== false) parts.push("HttpOnly");
  return parts.join("; ");
}

async function findSession(token: string | undefined): Promise<SiteUser | null> {
  if (!token) return null;
  const db = runtime().DB;
  await ensureAuthSchema(db);
  const row = await db.prepare(`SELECT u.discord_id AS discordId, u.username, u.display_name AS displayName, u.avatar, u.role, u.active, s.expires_at AS expiresAt
    FROM web_sessions s JOIN web_users u ON u.discord_id = s.discord_id WHERE s.token_hash = ?`).bind(await hashToken(token)).first<StoredUser & { expiresAt: number }>();
  if (!row || !row.active || !["admin", "reseller"].includes(row.role) || row.expiresAt <= Math.floor(Date.now() / 1000)) return null;
  return { discordId: row.discordId, username: row.username, displayName: row.displayName, avatar: row.avatar, role: row.role as SiteRole };
}

export async function getSiteUserFromRequest(request: Request) {
  return findSession(parseCookies(request.headers.get("cookie"))[SESSION_COOKIE]);
}

export async function getSiteUser() {
  const jar = await cookies();
  return findSession(jar.get(SESSION_COOKIE)?.value);
}

export async function getSiteAccess(request: Request) {
  const user = await getSiteUserFromRequest(request);
  if (user) return { user, owner: `discord:${user.discordId}`, admin: user.role === "admin" };
  throw new Error("Faca login para acessar o painel.");
}

export async function saveDiscordUser(user: { id: string; username: string; globalName?: string | null; avatar?: string | null }) {
  const db = runtime().DB;
  const config = authConfig();
  await ensureAuthSchema(db);
  const now = Math.floor(Date.now() / 1000);
  const existing = await db.prepare("SELECT role, active FROM web_users WHERE discord_id = ?").bind(user.id).first<{ role: string; active: number }>();
  if (existing && !existing.active) return null;
  const role = user.id === config.adminId ? "admin" : existing?.role || "pending";
  await db.prepare(`INSERT INTO web_users (discord_id, username, display_name, avatar, role, active, created_at, updated_at, last_login) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)
    ON CONFLICT(discord_id) DO UPDATE SET username = excluded.username, display_name = excluded.display_name, avatar = excluded.avatar, role = CASE WHEN web_users.role = 'admin' OR excluded.role = 'admin' THEN 'admin' ELSE web_users.role END, updated_at = excluded.updated_at, last_login = excluded.last_login`)
    .bind(user.id, user.username, user.globalName || user.username, user.avatar || "", role, now, now, now).run();
  if (role !== "admin" && role !== "reseller") return null;
  return { discordId: user.id, username: user.username, displayName: user.globalName || user.username, avatar: user.avatar || "", role: role as SiteRole } satisfies SiteUser;
}

export async function createSession(discordId: string) {
  const db = runtime().DB;
  const token = randomToken();
  const now = Math.floor(Date.now() / 1000);
  await db.prepare("INSERT INTO web_sessions (token_hash, discord_id, expires_at, created_at) VALUES (?, ?, ?, ?)").bind(await hashToken(token), discordId, now + 7 * 86400, now).run();
  return token;
}

export { SESSION_COOKIE, STATE_COOKIE, randomToken, parseCookies };
