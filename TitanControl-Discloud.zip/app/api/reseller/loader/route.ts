import { env } from "../../../server-runtime";
import { getSiteAccess } from "../../../discord-auth";

type Runtime = { DB?: D1Database; ARTIFACTS?: R2Bucket };
type ArtifactRow = { objectKey: string; fileName: string; size: number; chunked: number; partCount: number };

function runtime() {
  const value = env as unknown as Runtime;
  if (!value.DB || !value.ARTIFACTS) throw new Error("Armazenamento privado ainda não foi conectado.");
  return value as { DB: D1Database; ARTIFACTS: R2Bucket };
}

function write16(view: DataView, offset: number, value: number) { view.setUint16(offset, value, true); }
function write32(view: DataView, offset: number, value: number) { view.setUint32(offset, value >>> 0, true); }

function crc32(data: Uint8Array) {
  let crc = 0xffffffff;
  for (const byte of data) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function zipStore(files: Array<{ name: string; data: Uint8Array }>) {
  const encoder = new TextEncoder();
  const now = new Date();
  const dosTime = ((now.getHours() & 31) << 11) | ((now.getMinutes() & 63) << 5) | (Math.floor(now.getSeconds() / 2) & 31);
  const dosDate = (((now.getFullYear() - 1980) & 127) << 9) | (((now.getMonth() + 1) & 15) << 5) | (now.getDate() & 31);
  const entries = files.map((file) => ({ ...file, nameBytes: encoder.encode(file.name), crc: crc32(file.data), offset: 0 }));
  const localSize = entries.reduce((total, entry) => total + 30 + entry.nameBytes.length + entry.data.length, 0);
  const centralSize = entries.reduce((total, entry) => total + 46 + entry.nameBytes.length, 0);
  const archive = new Uint8Array(localSize + centralSize + 22);
  const view = new DataView(archive.buffer);
  let offset = 0;

  for (const entry of entries) {
    entry.offset = offset;
    write32(view, offset, 0x04034b50); write16(view, offset + 4, 20); write16(view, offset + 6, 0x0800);
    write16(view, offset + 8, 0); write16(view, offset + 10, dosTime); write16(view, offset + 12, dosDate);
    write32(view, offset + 14, entry.crc); write32(view, offset + 18, entry.data.length); write32(view, offset + 22, entry.data.length);
    write16(view, offset + 26, entry.nameBytes.length); write16(view, offset + 28, 0);
    archive.set(entry.nameBytes, offset + 30); archive.set(entry.data, offset + 30 + entry.nameBytes.length);
    offset += 30 + entry.nameBytes.length + entry.data.length;
  }

  const centralOffset = offset;
  for (const entry of entries) {
    write32(view, offset, 0x02014b50); write16(view, offset + 4, 20); write16(view, offset + 6, 20); write16(view, offset + 8, 0x0800);
    write16(view, offset + 10, 0); write16(view, offset + 12, dosTime); write16(view, offset + 14, dosDate);
    write32(view, offset + 16, entry.crc); write32(view, offset + 20, entry.data.length); write32(view, offset + 24, entry.data.length);
    write16(view, offset + 28, entry.nameBytes.length); write16(view, offset + 30, 0); write16(view, offset + 32, 0);
    write16(view, offset + 34, 0); write16(view, offset + 36, 0); write32(view, offset + 38, 0); write32(view, offset + 42, entry.offset);
    archive.set(entry.nameBytes, offset + 46); offset += 46 + entry.nameBytes.length;
  }

  write32(view, offset, 0x06054b50); write16(view, offset + 4, 0); write16(view, offset + 6, 0);
  write16(view, offset + 8, entries.length); write16(view, offset + 10, entries.length); write32(view, offset + 12, centralSize);
  write32(view, offset + 16, centralOffset); write16(view, offset + 20, 0);
  return archive;
}

async function readArtifact(bucket: R2Bucket, artifact: ArtifactRow) {
  if (!artifact.chunked) {
    const object = await bucket.get(artifact.objectKey);
    if (!object) throw new Error("Arquivo base do Loader não foi encontrado.");
    return new Uint8Array(await object.arrayBuffer());
  }

  const output = new Uint8Array(artifact.size);
  let offset = 0;
  for (let part = 1; part <= artifact.partCount; part += 1) {
    const object = await bucket.get(`${artifact.objectKey}/part-${part}`);
    if (!object) throw new Error(`O bloco ${part} do Loader não foi encontrado.`);
    const bytes = new Uint8Array(await object.arrayBuffer());
    output.set(bytes, offset);
    offset += bytes.length;
  }
  return output.slice(0, offset);
}

export async function GET(request: Request) {
  try {
    const { DB, ARTIFACTS } = runtime();
    const access = await getSiteAccess(request);
    const rebrandId = new URL(request.url).searchParams.get("rebrandId")?.trim() || "";
    if (!rebrandId) throw new Error("Rebrand não informado.");

    const rebrand = await DB.prepare(`SELECT id, name, slug, token FROM rebrands WHERE id = ? ${access.admin ? "" : "AND created_by = ?"}`)
      .bind(...(access.admin ? [rebrandId] : [rebrandId, access.owner]))
      .first<{ id: string; name: string; slug: string; token: string }>();
    if (!rebrand?.token) throw new Error("Rebrand não encontrado ou sem token.");

    const artifact = await DB.prepare("SELECT object_key AS objectKey, file_name AS fileName, size, chunked, part_count AS partCount FROM artifacts WHERE rebrand_id = '__base__' AND product = 'loader' ORDER BY created_at DESC LIMIT 1")
      .first<ArtifactRow>();
    if (!artifact) throw new Error("O Loader base ainda não foi publicado pelo administrador.");

    const loader = await readArtifact(ARTIFACTS, artifact);
    const archive = zipStore([
      { name: "Loader.exe", data: loader },
      { name: "token.txt", data: new TextEncoder().encode(`${rebrand.token}\r\n`) },
    ]);
    const fileName = `${(rebrand.slug || rebrand.name).replace(/[^a-zA-Z0-9._-]/g, "-") || "rebrand"}-loader.zip`;
    return new Response(archive, { headers: { "content-type": "application/zip", "content-disposition": `attachment; filename="${fileName}"`, "cache-control": "private, no-store" } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Não foi possível preparar o Loader." }, { status: 400, headers: { "cache-control": "no-store" } });
  }
}
