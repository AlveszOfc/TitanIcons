import { authConfig, cookieHeader, randomToken, STATE_COOKIE } from "../../../../discord-auth";

export async function GET(request: Request) {
  try {
    const config = authConfig();
    const state = randomToken(24);
    const url = new URL("https://discord.com/oauth2/authorize");
    url.searchParams.set("response_type", "code");
    url.searchParams.set("client_id", config.clientId);
    url.searchParams.set("scope", "identify guilds");
    url.searchParams.set("state", state);
    url.searchParams.set("redirect_uri", config.redirectUri);
    const response = new Response(null, { status: 302, headers: { Location: url.toString() } });
    response.headers.append("Set-Cookie", cookieHeader(STATE_COOKIE, state, { maxAge: 600 }));
    return response;
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Nao foi possivel iniciar o login." }, { status: 500 });
  }
}
