import { authConfig, cookieHeader, createSession, parseCookies, saveDiscordUser, STATE_COOKIE, SESSION_COOKIE } from "../../../../discord-auth";

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character] || character));
}

function publicHome(request: Request) {
  const redirectUri = process.env.DISCORD_REDIRECT_URI?.trim();
  if (redirectUri) {
    try { return new URL("/", redirectUri).toString(); } catch { /* usa o proxy abaixo */ }
  }
  const forwardedHost = request.headers.get("x-forwarded-host")?.split(",")[0]?.trim();
  const forwardedProto = request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim() || "https";
  if (forwardedHost) return `${forwardedProto}://${forwardedHost}/`;
  return new URL("/", request.url).toString();
}

function errorPage(message: string, request: Request) {
  const safe = escapeHtml(message);
  const home = escapeHtml(publicHome(request));
  return new Response(`<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Titan Control</title><body style="font-family:system-ui;background:#0b0d12;color:#f4f6fb;display:grid;place-items:center;min-height:100vh"><main style="max-width:520px;padding:32px;text-align:center"><h1>Não foi possível entrar</h1><p style="color:#aab1c4">${safe}</p><a style="color:#9eacff" href="${home}">Voltar ao login</a></main></body></html>`, { status: 400, headers: { "content-type": "text/html; charset=utf-8" } });
}

export async function GET(request: Request) {
  try {
    const config = authConfig();
    const url = new URL(request.url);
    const oauthError = url.searchParams.get("error")?.trim();
    if (oauthError) return errorPage("A autorização foi cancelada no Discord. Tente entrar novamente.", request);
    const code = url.searchParams.get("code")?.trim();
    const returnedState = url.searchParams.get("state")?.trim();
    const cookies = parseCookies(request.headers.get("cookie"));
    if (!code || !returnedState || cookies[STATE_COOKIE] !== returnedState) return errorPage("A autorização expirou ou não pôde ser validada. Tente novamente.", request);

    const tokenResponse = await fetch("https://discord.com/api/v10/oauth2/token", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ client_id: config.clientId, client_secret: config.clientSecret, grant_type: "authorization_code", code, redirect_uri: config.redirectUri }),
    });
    const tokenPayload = await tokenResponse.json() as { access_token?: string; error_description?: string };
    if (!tokenResponse.ok || !tokenPayload.access_token) return errorPage("Este código do Discord expirou ou já foi usado. Volte ao início e tente novamente.", request);

    const discordHeaders = { authorization: `Bearer ${tokenPayload.access_token}` };
    const [userResponse, guildsResponse] = await Promise.all([
      fetch("https://discord.com/api/v10/users/@me", { headers: discordHeaders }),
      fetch("https://discord.com/api/v10/users/@me/guilds", { headers: discordHeaders }),
    ]);
    const discordUser = await userResponse.json() as { id?: string; username?: string; global_name?: string | null; avatar?: string | null };
    const guilds = await guildsResponse.json() as Array<{ id?: string }>;
    if (!userResponse.ok || !discordUser.id || !discordUser.username) return errorPage("Não foi possível ler sua conta Discord.", request);
    if (!guildsResponse.ok || !guilds.some((guild) => guild.id === config.guildId)) return errorPage("Você precisa estar no servidor Discord autorizado para entrar.", request);

    const user = await saveDiscordUser({ id: discordUser.id, username: discordUser.username, globalName: discordUser.global_name, avatar: discordUser.avatar });
    if (!user) return errorPage("Sua conta Discord ainda não foi liberada pelo administrador.", request);
    const session = await createSession(user.discordId);
    const response = new Response(null, { status: 302, headers: { Location: publicHome(request) } });
    response.headers.append("Set-Cookie", cookieHeader(SESSION_COOKIE, session, { maxAge: 7 * 86400 }));
    response.headers.append("Set-Cookie", cookieHeader(STATE_COOKIE, "", { maxAge: 0 }));
    return response;
  } catch (error) {
    return errorPage(error instanceof Error ? error.message : "Erro inesperado no login.", request);
  }
}
