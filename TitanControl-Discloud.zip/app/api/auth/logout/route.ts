import { cookieHeader, hashToken, parseCookies, SESSION_COOKIE } from "../../../discord-auth";
import { env } from "../../../server-runtime";

export async function GET(request: Request) {
  const db = (env as unknown as { DB?: D1Database }).DB;
  const token = parseCookies(request.headers.get("cookie"))[SESSION_COOKIE];
  if (db && token) await db.prepare("DELETE FROM web_sessions WHERE token_hash = ?").bind(await hashToken(token)).run();
  const response = new Response(null, { status: 302, headers: { Location: new URL("/", request.url).toString() } });
  response.headers.append("Set-Cookie", cookieHeader(SESSION_COOKIE, "", { maxAge: 0 }));
  return response;
}
