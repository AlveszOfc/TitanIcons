import { env } from "../../server-runtime";
import { getSiteAccess } from "../../discord-auth";
import { listMemberships } from "../../rebrand-memberships";

type RuntimeEnvironment = {
  BOT_API_URL?: string;
  TITAN_API_SECRET?: string;
};

function getConfiguration() {
  const runtime = env as unknown as RuntimeEnvironment;
  const baseUrl = (runtime.BOT_API_URL || "https://titan-eoalvesz.discloud.app")
    .trim()
    .replace(/\/+$/, "");
  const secret = runtime.TITAN_API_SECRET?.trim() || "";

  if (!secret) {
    throw new Error("A conexão segura com o TitanBot ainda não foi configurada.");
  }

  return { baseUrl, secret };
}

async function readResponse(response: Response) {
  const text = await response.text();
  let payload: Record<string, unknown> = {};

  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { error: text || "O servidor retornou uma resposta inválida." };
  }

  if (!response.ok) {
    throw new Error(
      String(payload.error || payload.message || "Não foi possível concluir a ação.")
    );
  }

  return payload;
}

async function callBot(path: string, init?: RequestInit) {
  const { baseUrl, secret } = getConfiguration();
  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    cache: "no-store",
    headers: {
      "content-type": "application/json",
      "x-titan-secret": secret,
      ...(init?.headers || {}),
    },
  });

  return readResponse(response);
}

function accountKey(item: { username?: unknown; product?: unknown }) {
  const product = String(item.product || "").toLowerCase() === "legit" ? "legit" : "full";
  return `${product}:${String(item.username || "").trim().toLowerCase()}`;
}

function usefulSubscription(value: unknown) {
  const text = String(value || "").trim();
  return text && !["indisponível", "indisponivel", "unavailable"].includes(text.toLowerCase()) ? text : "";
}

export async function GET(request: Request) {
  try {
    const access = await getSiteAccess(request);
    const data = await callBot("/api/admin/dashboard");
    const dashboard = data as any;
    const database = (env as unknown as { DB?: D1Database }).DB;
    if (!database) throw new Error("Banco de dados ainda nao foi conectado.");
    let memberships: Awaited<ReturnType<typeof listMemberships>> = [];
    try {
      memberships = await listMemberships(database, access.admin ? undefined : access.owner);
    } catch (membershipError) {
      // O painel principal continua disponível mesmo se a tabela auxiliar
      // estiver sendo criada ou migrada em uma primeira requisição.
      console.error("[rebrand-membership] Falha ao carregar vínculos:", membershipError);
    }
    const membershipByAccount = new Map(memberships.map((item) => [accountKey(item), item]));
    const visibleTokens = new Set(memberships.map((item) => item.rebrandToken.trim()).filter(Boolean));
    if (!access.admin) {
      const owned = await database.prepare("SELECT token FROM rebrands WHERE created_by = ?").bind(access.owner).all<{ token: string }>();
      for (const item of owned.results || []) if (item.token?.trim()) visibleTokens.add(item.token.trim());
    }
    const botClients = Array.isArray(dashboard.clients) ? dashboard.clients : [];
    const botLicenses = Array.isArray(dashboard.licenses) ? dashboard.licenses : [];
    const isVisible = (item: any) => access.admin || visibleTokens.has(String(item.rebrandToken || "").trim()) || membershipByAccount.has(accountKey(item));
    const visibleOnlineClients = botClients.filter(isVisible).map((item: any) => {
      const membership = membershipByAccount.get(accountKey(item));
      return { ...item, online: true, rebrandToken: String(item.rebrandToken || membership?.rebrandToken || "") };
    });

    const licenses = memberships.map((membership) => {
      const candidates = botLicenses.filter((item: any) => accountKey(item) === accountKey(membership));
      const live = candidates.find((item: any) => String(item.rebrandToken || "").trim() === membership.rebrandToken.trim())
        || candidates.find((item: any) => !String(item.rebrandToken || "").trim());
      return {
        id: membership.id,
        username: live?.username || membership.username,
        product: membership.product,
        subscription: usefulSubscription(live?.subscription) || usefulSubscription(membership.subscription) || "Indisponível",
        licenseExpiry: Number(live?.licenseExpiry) || membership.licenseExpiry || 0,
        discordId: String(live?.discordId || ""),
        discordName: String(live?.discordName || ""),
        rebrandToken: membership.rebrandToken,
        firstSeen: Number(live?.firstSeen) || membership.firstSeen * 1000,
        lastSeen: Number(live?.lastSeen) || membership.lastSeen * 1000,
      };
    });
    const linkedAccounts = new Set(licenses.map(accountKey));
    for (const item of botLicenses.filter(isVisible)) {
      if (!linkedAccounts.has(accountKey(item))) licenses.push(item);
    }
    licenses.sort((left: any, right: any) => Number(right.lastSeen || 0) - Number(left.lastSeen || 0));

    const clients = access.admin ? visibleOnlineClients : memberships.map((membership) => {
      const live = visibleOnlineClients.find((item: any) => accountKey(item) === accountKey(membership)
        && (!String(item.rebrandToken || "").trim() || String(item.rebrandToken).trim() === membership.rebrandToken.trim()));
      return {
        id: live?.id || membership.id,
        username: live?.username || membership.username,
        product: membership.product,
        discordName: String(live?.discordName || ""),
        computer: String(live?.computer || ""),
        online: Boolean(live),
        lastHeartbeat: Number(live?.lastHeartbeat) || membership.lastSeen * 1000,
        rebrandToken: membership.rebrandToken,
      };
    });
    if (!access.admin) {
      const linkedClients = new Set(clients.map(accountKey));
      for (const item of visibleOnlineClients) if (!linkedClients.has(accountKey(item))) clients.push(item);
    }

    return Response.json({
      ...dashboard,
      health: { ...(dashboard.health || {}), usersOnline: visibleOnlineClients.length },
      products: access.admin ? dashboard.products : {},
      clients,
      licenses,
      latestAnnouncement: access.admin ? dashboard.latestAnnouncement : null,
      activities: access.admin ? dashboard.activities : [],
    }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    console.error("[control] Falha ao montar painel:", error);
    return Response.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "O painel não conseguiu falar com o TitanBot.",
      },
      { status: 502 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const access = await getSiteAccess(request);
    if (!access.admin) return Response.json({ error: "Apenas o administrador pode executar ações." }, { status: 403 });
    const body = (await request.json()) as {
      operation?: string;
      [key: string]: unknown;
    };
    const routes: Record<string, string> = {
      product_status: "/api/admin/product-status",
      broadcast: "/api/admin/broadcast",
      client_command: "/api/admin/command",
    };
    const path = routes[String(body.operation || "")];

    if (!path) {
      return Response.json({ error: "Ação desconhecida." }, { status: 400 });
    }

    const payload = { ...body };
    delete payload.operation;
    const data = await callBot(path, {
      method: "POST",
      body: JSON.stringify(payload),
    });
    return Response.json(data);
  } catch (error) {
    return Response.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Não foi possível concluir a ação.",
      },
      { status: 502 }
    );
  }
}
