import { env } from "../../server-runtime";
import { getSiteAccess } from "../../discord-auth";
import { ensureMembershipSchema } from "../../rebrand-memberships";

type Runtime = { DB?: D1Database };
type RebrandInput = {
  id?: string;
  name?: string;
  slug?: string;
  product?: string;
  primaryColor?: string;
  secondaryColor?: string;
  loaderTitle?: string;
  dllTitle?: string;
  logoUrl?: string;
  rotateToken?: boolean;
};

function getDb() {
  const db = (env as unknown as Runtime).DB;
  if (!db) throw new Error("Banco de rebrands ainda não foi conectado.");
  return db;
}

async function ensureSchema(db: D1Database) {
  await db.prepare(`CREATE TABLE IF NOT EXISTS rebrands (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    product TEXT NOT NULL DEFAULT 'full',
    primary_color TEXT NOT NULL DEFAULT '#7c8cff',
    secondary_color TEXT NOT NULL DEFAULT '#131720',
    loader_title TEXT NOT NULL DEFAULT '',
    dll_title TEXT NOT NULL DEFAULT '',
    logo_url TEXT NOT NULL DEFAULT '',
    token_hash TEXT NOT NULL UNIQUE,
    token TEXT NOT NULL DEFAULT '',
    version INTEGER NOT NULL DEFAULT 1,
    created_by TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`).run();
  try { await db.prepare("ALTER TABLE rebrands ADD COLUMN token TEXT NOT NULL DEFAULT ''").run(); } catch { /* coluna já existe */ }
  await db.prepare("UPDATE rebrands SET product = 'both' WHERE product <> 'both'").run();
}

function clean(value: unknown, fallback = "", max = 120) {
  return String(value ?? fallback).trim().slice(0, max);
}

function validColor(value: string, fallback: string) {
  return /^#[0-9a-f]{6}$/i.test(value) ? value : fallback;
}

function token() {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return `TS-${Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}

async function hash(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function GET(request: Request) {
  try {
    const access = await getSiteAccess(request);
    const db = getDb();
    await ensureSchema(db);
    const result = await db.prepare(`SELECT id, name, slug, product, primary_color AS primaryColor,
      secondary_color AS secondaryColor, loader_title AS loaderTitle, dll_title AS dllTitle,
      logo_url AS logoUrl, token, version, created_at AS createdAt, updated_at AS updatedAt
      FROM rebrands ${access.admin ? "" : "WHERE created_by = ?"} ORDER BY updated_at DESC`).bind(...(access.admin ? [] : [access.owner])).all();
    return Response.json({ rebrands: result.results || [] }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Não foi possível carregar os rebrands." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const access = await getSiteAccess(request);
    const input = (await request.json()) as { id?: string };
    const id = clean(input.id, "", 80);
    if (!id) return Response.json({ error: "Rebrand inválido." }, { status: 400 });
    const db = getDb();
    await ensureSchema(db);
    await ensureMembershipSchema(db);
    const owned = await db.prepare(`SELECT id FROM rebrands WHERE id = ? ${access.admin ? "" : "AND created_by = ?"}`).bind(...(access.admin ? [id] : [id, access.owner])).first();
    if (owned) await db.batch([
      db.prepare("DELETE FROM rebrand_memberships WHERE rebrand_id = ?").bind(id),
      db.prepare("DELETE FROM rebrands WHERE id = ?").bind(id),
    ]);
    return Response.json({ ok: true, id });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Não foi possível excluir o rebrand." }, { status: 400 });
  }
}

export async function POST(request: Request) {
  try {
    const access = await getSiteAccess(request);
    const owner = access.owner;
    const input = (await request.json()) as RebrandInput;
    const db = getDb();
    await ensureSchema(db);
    const now = Math.floor(Date.now() / 1000);
    const id = clean(input.id, crypto.randomUUID(), 80);
    const name = clean(input.name, "Nova marca", 80);
    const slug = clean(input.slug, name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""), 50) || `rebrand-${Date.now()}`;
    const product = "both";
    const primaryColor = validColor(clean(input.primaryColor), "#7c8cff");
    const secondaryColor = validColor(clean(input.secondaryColor), "#131720");
    const loaderTitle = clean(input.loaderTitle, name, 100);
    const dllTitle = clean(input.dllTitle, name, 100);
    const logoUrl = clean(input.logoUrl, "", 500);
    const nextToken = token();
    const nextHash = await hash(nextToken);
    const existing = await db.prepare("SELECT id, token_hash AS tokenHash FROM rebrands WHERE id = ? AND created_by = ?").bind(id, owner).first<{ id: string; tokenHash: string }>();
    if (existing) {
      const tokenHash = input.rotateToken ? nextHash : existing.tokenHash;
      await db.prepare(`UPDATE rebrands SET name = ?, slug = ?, product = ?, primary_color = ?, secondary_color = ?, loader_title = ?, dll_title = ?, logo_url = ?, token_hash = ?, token = CASE WHEN ? = 1 THEN ? ELSE token END, version = version + 1, updated_at = ? WHERE id = ? AND created_by = ?`)
        .bind(name, slug, product, primaryColor, secondaryColor, loaderTitle, dllTitle, logoUrl, tokenHash, input.rotateToken ? 1 : 0, input.rotateToken ? nextToken : "", now, id, owner).run();
      return Response.json({ ok: true, id, rotatedToken: Boolean(input.rotateToken), token: input.rotateToken ? nextToken : undefined });
    }
    await db.prepare(`INSERT INTO rebrands (id, name, slug, product, primary_color, secondary_color, loader_title, dll_title, logo_url, token_hash, token, version, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`)
      .bind(id, name, slug, product, primaryColor, secondaryColor, loaderTitle, dllTitle, logoUrl, nextHash, nextToken, owner, now, now).run();
    return Response.json({ ok: true, id, token: nextToken, created: true });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Não foi possível salvar o rebrand." }, { status: 400 });
  }
}
