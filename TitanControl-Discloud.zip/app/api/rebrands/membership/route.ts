import { env } from "../../../server-runtime";
import { findRebrandByToken, saveMembership } from "../../../rebrand-memberships";
import { AuthorizationError, verifyKeyAuthSession } from "../../../keyauth-session";

type Runtime = { DB?: D1Database };

export async function POST(request: Request) {
  try {
    const db = (env as unknown as Runtime).DB;
    if (!db) throw new Error("Banco de dados ainda não foi conectado.");
    const body = (await request.json()) as {
      rebrandToken?: string;
      username?: string;
      product?: string;
      subscription?: string;
      licenseExpiry?: number;
      hwid?: string;
      keyAuthSession?: string;
    };
    const rebrand = await findRebrandByToken(db, String(body.rebrandToken || ""));
    if (!rebrand) throw new AuthorizationError("Rebrand inválido.");
    const product = String(body.product || "").trim().toLowerCase() === "legit" ? "legit" : "full";
    const verifiedSession = await verifyKeyAuthSession(body.keyAuthSession, product);
    await saveMembership(db, {
      rebrandId: rebrand.id,
      username: verifiedSession.username || String(body.username || ""),
      product,
      hwid: String(body.hwid || ""),
    });
    return Response.json({ ok: true }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    const status = error instanceof AuthorizationError ? error.status : 400;
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "Não foi possível vincular a licença." }, { status });
  }
}
