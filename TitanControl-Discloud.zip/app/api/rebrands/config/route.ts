import { env } from "../../../server-runtime";

type Runtime = { DB?: D1Database };

async function hash(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get("token")?.trim();
  const db = (env as unknown as Runtime).DB;
  if (!token || !db) return Response.json({ error: "Configuração indisponível." }, { status: 404 });
  const result = await db.prepare(`SELECT id, name, slug, product, primary_color AS primaryColor,
    secondary_color AS secondaryColor, loader_title AS loaderTitle, dll_title AS dllTitle,
    logo_url AS logoUrl, version, updated_at AS updatedAt FROM rebrands WHERE token_hash = ?`)
    .bind(await hash(token)).first();
  if (!result) return Response.json({ error: "Token inválido." }, { status: 404 });
  return Response.json({ config: result }, { headers: { "cache-control": "no-store" } });
}
