import { env } from "../../../server-runtime";
import { authConfig, ensureAuthSchema, getSiteAccess } from "../../../discord-auth";

function db() {
  const value = env as unknown as { DB?: D1Database };
  if (!value.DB) throw new Error("Banco de dados ainda nao foi conectado.");
  return value.DB;
}

function validDiscordId(value: unknown) {
  const id = String(value || "").trim();
  if (!/^\d{17,20}$/.test(id)) throw new Error("Informe um ID de Discord valido.");
  return id;
}

export async function GET(request: Request) {
  try {
    const access = await getSiteAccess(request);
    if (!access.admin) return Response.json({ error: "Acesso restrito ao administrador." }, { status: 403 });
    const database = db();
    await ensureAuthSchema(database);
    const result = await database.prepare(`SELECT discord_id AS discordId, username, display_name AS displayName, role, active, created_at AS createdAt, last_login AS lastLogin FROM web_users WHERE role = 'reseller' ORDER BY display_name COLLATE NOCASE`).all();
    return Response.json({ resellers: result.results || [] }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Nao foi possivel carregar os revendedores." }, { status: 400 });
  }
}

export async function POST(request: Request) {
  try {
    const access = await getSiteAccess(request);
    if (!access.admin) return Response.json({ error: "Acesso restrito ao administrador." }, { status: 403 });
    const input = (await request.json()) as { discordId?: string; displayName?: string };
    const discordId = validDiscordId(input.discordId);
    if (discordId === authConfig().adminId) throw new Error("Esse ID ja e o administrador.");
    const database = db();
    await ensureAuthSchema(database);
    const now = Math.floor(Date.now() / 1000);
    const displayName = String(input.displayName || discordId).trim().slice(0, 80) || discordId;
    await database.prepare(`INSERT INTO web_users (discord_id, username, display_name, avatar, role, active, created_at, updated_at, last_login) VALUES (?, ?, ?, '', 'reseller', 1, ?, ?, 0)
      ON CONFLICT(discord_id) DO UPDATE SET role = 'reseller', active = 1, display_name = CASE WHEN web_users.display_name = web_users.discord_id THEN excluded.display_name ELSE web_users.display_name END, updated_at = excluded.updated_at`).bind(discordId, displayName, displayName, now, now).run();
    return Response.json({ ok: true, discordId });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Nao foi possivel adicionar o revendedor." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const access = await getSiteAccess(request);
    if (!access.admin) return Response.json({ error: "Acesso restrito ao administrador." }, { status: 403 });
    const discordId = validDiscordId(((await request.json()) as { discordId?: string }).discordId);
    if (discordId === authConfig().adminId) throw new Error("O administrador nao pode ser removido.");
    const database = db();
    await ensureAuthSchema(database);
    await database.batch([
      database.prepare("DELETE FROM web_sessions WHERE discord_id = ?").bind(discordId),
      database.prepare("DELETE FROM web_users WHERE discord_id = ? AND role = 'reseller'").bind(discordId),
    ]);
    return Response.json({ ok: true, discordId });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Nao foi possivel remover o revendedor." }, { status: 400 });
  }
}
