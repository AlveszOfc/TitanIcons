import { env } from "../../../server-runtime";
import { findRebrandByToken, saveMembership, sha256 } from "../../../rebrand-memberships";
import { enforceArtifactRateLimit } from "../../../artifact-security";
import { AuthorizationError, verifyKeyAuthSession } from "../../../keyauth-session";

type Runtime = { DB?: D1Database };

export async function POST(request: Request) {
  try {
    const runtime = env as unknown as Runtime;
    const db = runtime.DB;
    if (!db) throw new Error("Armazenamento privado ainda nao foi conectado.");

    const body = (await request.json()) as { rebrandToken?: string; keyAuthSession?: string; username?: string; product?: string; hwid?: string; subscription?: string; licenseExpiry?: number };
    const rebrandToken = String(body.rebrandToken || "").trim();
    let username = String(body.username || "").trim();
    const product = String(body.product || "full").trim().toLowerCase() === "legit" ? "legit" : "full";
    const hwid = String(body.hwid || "").trim();
    if (!rebrandToken || !username || !hwid) throw new AuthorizationError("Token do rebrand, usuário e HWID são obrigatórios.", 400);

    await enforceArtifactRateLimit(db, request, rebrandToken);
    const rebrand = await findRebrandByToken(db, rebrandToken);
    if (!rebrand) throw new AuthorizationError("Rebrand inválido.");
    const verifiedSession = await verifyKeyAuthSession(body.keyAuthSession, product);
    if (verifiedSession.username) username = verifiedSession.username;
    try {
      await saveMembership(db, { rebrandId: rebrand.id, username, product, hwid });
    } catch (membershipError) {
      // O histórico do painel é complementar. Uma falha ao atualizá-lo nunca
      // pode impedir o cliente autenticado de baixar o arquivo do produto.
      console.error("[rebrand-membership] Falha ao salvar vínculo durante o download:", membershipError);
    }
    const latest = await db.prepare("SELECT id FROM artifacts WHERE rebrand_id = ? AND product = ? ORDER BY created_at DESC LIMIT 1").bind(rebrand.id, product).first<{ id: string }>();
    let artifactId = latest?.id || "";
    if (!artifactId) {
      const base = await db.prepare("SELECT id FROM artifacts WHERE rebrand_id = '__base__' AND product = ? ORDER BY created_at DESC LIMIT 1").bind(product).first<{ id: string }>();
      artifactId = base?.id || "";
    }
    if (!artifactId) throw new Error("Nenhuma DLL publicada para este produto.");

    const artifact = await db.prepare("SELECT id, file_name AS fileName FROM artifacts WHERE id = ?").bind(artifactId).first<{ id: string; fileName: string }>();
    if (!artifact) throw new Error("Versao privada nao encontrada.");
    const rawToken = crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
    const expiresAt = Math.floor(Date.now() / 1000) + 120;
    await db.prepare("DELETE FROM artifact_links WHERE expires_at <= ? OR downloads > 0").bind(Math.floor(Date.now() / 1000)).run();
    await db.prepare("INSERT INTO artifact_links (token_hash, artifact_id, created_by, expires_at, downloads) SELECT ?, id, created_by, ?, 0 FROM artifacts WHERE id = ?")
      .bind(await sha256(rawToken), expiresAt, artifactId).run();
    const url = new URL(`/api/artifacts/download?token=${encodeURIComponent(rawToken)}`, request.url);
    return Response.json({ approved: true, fileName: artifact.fileName, url: url.toString(), expiresAt }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    console.error("[artifact-authorize] Falha ao autorizar download:", error);
    const status = error instanceof AuthorizationError ? error.status : 400;
    return Response.json({ approved: false, error: error instanceof Error ? error.message : "Falha ao autorizar o download." }, { status });
  }
}
