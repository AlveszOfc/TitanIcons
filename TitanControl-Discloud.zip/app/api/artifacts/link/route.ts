import { env } from "../../../server-runtime";
import { getSiteAccess } from "../../../discord-auth";

type Runtime = { DB?: D1Database };

async function hash(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function POST(request: Request) {
  try {
    const db = (env as unknown as Runtime).DB;
    const access = await getSiteAccess(request);
    if (!access.admin) throw new Error("Acesso restrito ao administrador.");
    const createdBy = access.owner;
    if (!db) throw new Error("Faça login para liberar arquivos.");
    const body = (await request.json()) as { artifactId?: string; expiresIn?: number };
    const artifactId = String(body.artifactId || "").trim();
    const artifact = await db.prepare(`SELECT id FROM artifacts WHERE id = ? ${access.admin ? "" : "AND created_by = ?"}`).bind(...(access.admin ? [artifactId] : [artifactId, createdBy])).first();
    if (!artifact) throw new Error("Arquivo não encontrado.");
    const expiresIn = Math.min(Math.max(Number(body.expiresIn) || 3600, 60), 604800);
    const rawToken = crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
    await db.prepare("INSERT INTO artifact_links (token_hash, artifact_id, created_by, expires_at, downloads) VALUES (?, ?, ?, ?, 0)")
      .bind(await hash(rawToken), artifactId, createdBy, Math.floor(Date.now() / 1000) + expiresIn).run();
    const url = new URL(`/api/artifacts/download?token=${encodeURIComponent(rawToken)}`, request.url);
    return Response.json({ ok: true, url: url.toString(), expiresIn });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Não foi possível gerar o link." }, { status: 400 });
  }
}
