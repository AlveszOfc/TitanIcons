import { env } from "../../../server-runtime";

type Runtime = { DB?: D1Database; ARTIFACTS?: R2Bucket };

async function hash(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function GET(request: Request) {
  const runtime = env as unknown as Runtime;
  const rawToken = new URL(request.url).searchParams.get("token")?.trim();
  if (!runtime.DB || !runtime.ARTIFACTS || !rawToken) return new Response("Link invalido.", { status: 404 });
  const row = await runtime.DB.prepare(`SELECT a.object_key AS objectKey, a.file_name AS fileName, a.content_type AS contentType, a.size, a.chunked, a.part_count AS partCount, l.expires_at AS expiresAt
    FROM artifact_links l JOIN artifacts a ON a.id = l.artifact_id WHERE l.token_hash = ?`).bind(await hash(rawToken)).first<{ objectKey: string; fileName: string; contentType: string; size: number; chunked: number; partCount: number; expiresAt: number }>();
  if (!row || row.expiresAt <= Math.floor(Date.now() / 1000)) return new Response("Link expirado.", { status: 410 });
  const claimed = await runtime.DB.prepare("DELETE FROM artifact_links WHERE token_hash = ? AND downloads = 0 AND expires_at > ?")
    .bind(await hash(rawToken), Math.floor(Date.now() / 1000)).run();
  if (!claimed.meta.changes) return new Response("Link já utilizado ou expirado.", { status: 410 });
  const headers = { "content-type": row.contentType, "content-length": String(row.size), "content-disposition": `attachment; filename="${row.fileName.replace(/"/g, "")}"`, "cache-control": "private, no-store" };
  if (!row.chunked) {
    const object = await runtime.ARTIFACTS.get(row.objectKey);
    if (!object) return new Response("Arquivo nao encontrado.", { status: 404 });
    return new Response(object.body, { headers });
  }
  const body = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        for (let partNumber = 1; partNumber <= row.partCount; partNumber++) {
          const part = await runtime.ARTIFACTS!.get(`${row.objectKey}/part-${partNumber}`);
          if (!part) throw new Error("Parte do arquivo nao encontrada.");
          const reader = part.body.getReader();
          while (true) {
            const next = await reader.read();
            if (next.done) break;
            controller.enqueue(next.value);
          }
        }
        controller.close();
      } catch (error) {
        controller.error(error);
      }
    },
  });
  return new Response(body, { headers });
}
