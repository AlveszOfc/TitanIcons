import { env } from "../../server-runtime";
import { getSiteAccess } from "../../discord-auth";

type Runtime = { DB?: D1Database; ARTIFACTS?: R2Bucket };

function runtime() {
  const value = env as unknown as Runtime;
  if (!value.DB || !value.ARTIFACTS) throw new Error("Armazenamento privado ainda não foi conectado.");
  return value as { DB: D1Database; ARTIFACTS: R2Bucket };
}

function safeName(value: string) {
  return value.replace(/[^a-zA-Z0-9._-]/g, "-").slice(0, 120) || "arquivo.bin";
}

async function deleteChunkedObject(bucket: R2Bucket, prefix: string, partCount: number) {
  const batchSize = 32;
  for (let start = 1; start <= partCount; start += batchSize) {
    const keys = Array.from({ length: Math.min(batchSize, partCount - start + 1) }, (_, index) => `${prefix}/part-${start + index}`);
    await Promise.all(keys.map((key) => bucket.delete(key)));
  }
}

function randomToken() {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function hash(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function ensureSchema(db: D1Database) {
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS artifacts (
      id TEXT PRIMARY KEY, rebrand_id TEXT NOT NULL, object_key TEXT NOT NULL UNIQUE,
      file_name TEXT NOT NULL, content_type TEXT NOT NULL, size INTEGER NOT NULL,
      created_by TEXT NOT NULL, created_at INTEGER NOT NULL
    )`),
    db.prepare(`CREATE TABLE IF NOT EXISTS artifact_links (
      token_hash TEXT PRIMARY KEY, artifact_id TEXT NOT NULL, created_by TEXT NOT NULL,
      expires_at INTEGER NOT NULL, downloads INTEGER NOT NULL DEFAULT 0
    )`),
  ]);
  for (const statement of [
    "ALTER TABLE artifacts ADD COLUMN chunked INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE artifacts ADD COLUMN part_count INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE artifacts ADD COLUMN product TEXT NOT NULL DEFAULT 'full'",
  ]) {
    try { await db.prepare(statement).run(); } catch { /* column already exists */ }
  }
}

export async function GET(request: Request) {
  try {
    const db = runtime().DB;
    const access = await getSiteAccess(request);
    if (!access.admin) throw new Error("Acesso restrito ao administrador.");
    await ensureSchema(db);
    const rebrandId = new URL(request.url).searchParams.get("rebrandId")?.trim();
    const result = rebrandId
      ? await db.prepare(`SELECT id, rebrand_id AS rebrandId, product, file_name AS fileName, content_type AS contentType, size, created_at AS createdAt FROM artifacts WHERE ${access.admin ? "" : "created_by = ? AND "}rebrand_id = ? ORDER BY created_at DESC`).bind(...(access.admin ? [rebrandId] : [access.owner, rebrandId])).all()
      : await db.prepare(`SELECT id, rebrand_id AS rebrandId, product, file_name AS fileName, content_type AS contentType, size, created_at AS createdAt FROM artifacts ${access.admin ? "" : "WHERE created_by = ?"} ORDER BY created_at DESC`).bind(...(access.admin ? [] : [access.owner])).all();
    return Response.json({ artifacts: result.results || [] }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Não foi possível carregar os arquivos." }, { status: 400 });
  }
}

export async function POST(request: Request) {
  try {
    const { DB, ARTIFACTS } = runtime();
    const access = await getSiteAccess(request);
    if (!access.admin) throw new Error("Acesso restrito ao administrador.");
    const createdBy = access.owner;
    await ensureSchema(DB);
    const form = await request.formData();
    const file = form.get("file");
    const rebrandId = String(form.get("rebrandId") || "").trim();
    const product = String(form.get("product") || "full").trim().toLowerCase();
    if (!(file instanceof File) || !rebrandId) throw new Error("Selecione um arquivo e um rebrand.");
    if (product !== "full" && product !== "legit" && product !== "loader") throw new Error("Produto invalido.");
    if (file.size > 100 * 1024 * 1024) throw new Error("O arquivo ultrapassa o limite de 100 MB.");
    const rebrand = await DB.prepare(`SELECT id FROM rebrands WHERE id = ? ${access.admin ? "" : "AND created_by = ?"}`).bind(...(access.admin ? [rebrandId] : [rebrandId, createdBy])).first();
    if (!rebrand) throw new Error("Rebrand não encontrado.");
    const id = crypto.randomUUID();
    const fileName = safeName(file.name);
    const objectKey = `${createdBy.replace(/[^a-zA-Z0-9]/g, "_")}/${rebrandId}/${id}-${fileName}`;
    await ARTIFACTS.put(objectKey, file.stream(), { httpMetadata: { contentType: file.type || "application/octet-stream" } });
    await DB.prepare(`INSERT INTO artifacts (id, rebrand_id, object_key, file_name, content_type, size, created_by, created_at, product) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(id, rebrandId, objectKey, fileName, file.type || "application/octet-stream", file.size, createdBy, Math.floor(Date.now() / 1000), product).run();
    return Response.json({ ok: true, id, fileName });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Não foi possível enviar o arquivo." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { DB, ARTIFACTS } = runtime();
    const access = await getSiteAccess(request);
    if (!access.admin) throw new Error("Acesso restrito ao administrador.");
    const createdBy = access.owner;
    await ensureSchema(DB);
    const body = (await request.json()) as { artifactId?: string };
    const artifactId = String(body.artifactId || "").trim();
    if (!artifactId) throw new Error("Arquivo nao informado.");
    const artifact = await DB.prepare(`SELECT id, object_key AS objectKey, chunked, part_count AS partCount FROM artifacts WHERE id = ? ${access.admin ? "" : "AND created_by = ?"}`).bind(...(access.admin ? [artifactId] : [artifactId, createdBy])).first<{ id: string; objectKey: string; chunked: number; partCount: number }>();
    if (!artifact) throw new Error("Arquivo nao encontrado.");
    if (artifact.chunked) {
      await deleteChunkedObject(ARTIFACTS, artifact.objectKey, artifact.partCount);
    } else {
      await ARTIFACTS.delete(artifact.objectKey);
    }
    await DB.batch([
      DB.prepare(`DELETE FROM artifact_links WHERE artifact_id = ? ${access.admin ? "" : "AND created_by = ?"}`).bind(...(access.admin ? [artifactId] : [artifactId, createdBy])),
      DB.prepare(`DELETE FROM artifacts WHERE id = ? ${access.admin ? "" : "AND created_by = ?"}`).bind(...(access.admin ? [artifactId] : [artifactId, createdBy])),
    ]);
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Nao foi possivel excluir o arquivo." }, { status: 400 });
  }
}
