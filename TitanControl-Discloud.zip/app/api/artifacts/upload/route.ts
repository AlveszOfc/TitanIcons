import { env } from "../../../server-runtime";
import { getSiteAccess } from "../../../discord-auth";

type Runtime = { DB?: D1Database; ARTIFACTS?: R2Bucket };

function runtime() {
  const value = env as unknown as Runtime;
  if (!value.DB || !value.ARTIFACTS) throw new Error("Armazenamento privado ainda nao foi conectado.");
  return value as { DB: D1Database; ARTIFACTS: R2Bucket };
}

function safeName(value: string) {
  return value.replace(/[^a-zA-Z0-9._-]/g, "-").slice(0, 120) || "arquivo.bin";
}

async function ensureSchema(db: D1Database) {
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS artifacts (id TEXT PRIMARY KEY, rebrand_id TEXT NOT NULL, object_key TEXT NOT NULL UNIQUE, file_name TEXT NOT NULL, content_type TEXT NOT NULL, size INTEGER NOT NULL, created_by TEXT NOT NULL, created_at INTEGER NOT NULL, product TEXT NOT NULL DEFAULT 'full')`),
    db.prepare(`CREATE TABLE IF NOT EXISTS artifact_uploads (id TEXT PRIMARY KEY, object_key TEXT NOT NULL UNIQUE, upload_id TEXT NOT NULL, rebrand_id TEXT NOT NULL, file_name TEXT NOT NULL, content_type TEXT NOT NULL, size INTEGER NOT NULL, created_by TEXT NOT NULL, created_at INTEGER NOT NULL, product TEXT NOT NULL DEFAULT 'full')`),
  ]);
  for (const statement of [
    "ALTER TABLE artifacts ADD COLUMN chunked INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE artifacts ADD COLUMN part_count INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE artifacts ADD COLUMN product TEXT NOT NULL DEFAULT 'full'",
    "ALTER TABLE artifact_uploads ADD COLUMN product TEXT NOT NULL DEFAULT 'full'",
  ]) {
    try { await db.prepare(statement).run(); } catch { /* column already exists */ }
  }
}

export async function POST(request: Request) {
  try {
    const { DB, ARTIFACTS } = runtime();
    const access = await getSiteAccess(request);
    if (!access.admin) throw new Error("Acesso restrito ao administrador.");
    const createdBy = access.owner;
    await ensureSchema(DB);
    const form = await request.formData();
    const action = String(form.get("action") || "").trim();

    if (action === "init") {
      const rebrandId = String(form.get("rebrandId") || "").trim();
      const product = String(form.get("product") || "full").trim().toLowerCase();
      const fileName = safeName(String(form.get("fileName") || "arquivo.bin"));
      const contentType = String(form.get("contentType") || "application/octet-stream");
      const size = Number(form.get("size") || 0);
      if (!rebrandId || !size) throw new Error("Selecione um rebrand e um arquivo.");
      if (product !== "full" && product !== "legit" && product !== "loader") throw new Error("Produto invalido.");
      if (size > 100 * 1024 * 1024) throw new Error("O arquivo ultrapassa o limite de 100 MB.");
      if (rebrandId !== "__base__") {
        const rebrand = await DB.prepare(`SELECT id FROM rebrands WHERE id = ? ${access.admin ? "" : "AND created_by = ?"}`).bind(...(access.admin ? [rebrandId] : [rebrandId, createdBy])).first();
        if (!rebrand) throw new Error("Rebrand nao encontrado.");
      }
      const id = crypto.randomUUID();
      const objectKey = `${createdBy.replace(/[^a-zA-Z0-9]/g, "_")}/${rebrandId}/${id}-${fileName}`;
      await DB.prepare("INSERT INTO artifact_uploads (id, object_key, upload_id, rebrand_id, file_name, content_type, size, created_by, created_at, product) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
        .bind(id, objectKey, "chunked", rebrandId, fileName, contentType, size, createdBy, Math.floor(Date.now() / 1000), product).run();
      return Response.json({ ok: true, uploadId: id, totalParts: Math.ceil(size / (256 * 1024)) });
    }

    const uploadId = String(form.get("uploadId") || "").trim();
    const upload = await DB.prepare("SELECT * FROM artifact_uploads WHERE id = ? AND created_by = ?").bind(uploadId, createdBy).first<{ id: string; object_key: string; upload_id: string; rebrand_id: string; file_name: string; content_type: string; size: number; created_by: string; created_at: number; product: string }>();
    if (!upload) throw new Error("Upload nao encontrado ou expirado.");
    if (action === "part") {
      const part = form.get("part");
      const partNumber = Number(form.get("partNumber") || 0);
      if (!(part instanceof File) || !partNumber) throw new Error("Parte do arquivo invalida.");
      await ARTIFACTS.put(`${upload.object_key}/part-${partNumber}`, part.stream(), { httpMetadata: { contentType: upload.content_type } });
      return Response.json({ ok: true, partNumber, etag: `part-${partNumber}` });
    }

    if (action === "complete") {
      const parts = JSON.parse(String(form.get("parts") || "[]")) as Array<{ partNumber: number; etag: string }>;
      if (!parts.length) throw new Error("Nenhuma parte foi enviada.");
      const artifactId = crypto.randomUUID();
      await DB.batch([
        DB.prepare("INSERT INTO artifacts (id, rebrand_id, object_key, file_name, content_type, size, created_by, created_at, chunked, part_count, product) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)").bind(artifactId, upload.rebrand_id, upload.object_key, upload.file_name, upload.content_type, upload.size, createdBy, upload.created_at, parts.length, upload.product),
        DB.prepare("DELETE FROM artifact_uploads WHERE id = ? AND created_by = ?").bind(uploadId, createdBy),
      ]);
      return Response.json({ ok: true, id: artifactId, fileName: upload.file_name });
    }

    throw new Error("Acao de upload invalida.");
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Nao foi possivel enviar o arquivo." }, { status: 400 });
  }
}
