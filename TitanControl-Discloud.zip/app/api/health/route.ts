import { checkDatabaseConnection } from "../../server-runtime";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const database = await checkDatabaseConnection();
    return Response.json({ ok: database, service: "Titan Control" }, {
      status: database ? 200 : 503,
      headers: { "cache-control": "no-store" },
    });
  } catch {
    return Response.json({ ok: false, service: "Titan Control" }, {
      status: 503,
      headers: { "cache-control": "no-store" },
    });
  }
}
