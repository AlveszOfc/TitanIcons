"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import type { SiteUser } from "./auth-types";

type ProductId = "full" | "legit";
type ArtifactProduct = ProductId | "loader";
type RebrandProduct = "both";
type Section =
  | "overview"
  | "products"
  | "customers"
  | "licenses"
  | "brands"
  | "dlls"
  | "settings"
  | "resellers";

type ProductStatus = {
  working: boolean;
  message: string;
  updatedAt: number;
  updatedBy: string;
};

type Client = {
  id: string;
  product: ProductId;
  username: string;
  windowsUsername: string;
  computer: string;
  discordId: string;
  discordName: string;
  subscription: string;
  licenseExpiry: number;
  connectedAt: number;
  lastHeartbeat: number;
  rebrandToken: string;
};

type License = {
  username: string;
  product: ProductId;
  subscription: string;
  licenseExpiry: number;
  discordId: string;
  discordName: string;
  firstSeen: number;
  lastSeen: number;
  rebrandToken: string;
};

type Activity = {
  id: string;
  type: string;
  title: string;
  detail: string;
  createdAt: number;
};

type Rebrand = {
  id: string;
  name: string;
  slug: string;
  product: RebrandProduct;
  primaryColor: string;
  secondaryColor: string;
  loaderTitle: string;
  dllTitle: string;
  logoUrl: string;
  token: string;
  version: number;
  createdAt: number;
  updatedAt: number;
};

type Artifact = {
  id: string;
  rebrandId: string;
  product: ArtifactProduct;
  fileName: string;
  contentType: string;
  size: number;
  createdAt: number;
};

type DashboardData = {
  generatedAt: number;
  health: {
    version: string;
    uptimeSeconds: number;
    usersOnline: number;
    memoryMb: number;
  };
  products: Record<ProductId, ProductStatus>;
  clients: Client[];
  licenses: License[];
  latestAnnouncement: {
    id: number;
    message: string;
    authorId: string;
    createdAt: number;
    delivered: number;
  } | null;
  activities: Activity[];
};

const navigation: Array<{ id: Section; label: string; icon: string }> = [
  { id: "overview", label: "Visão geral", icon: "⌂" },
  { id: "products", label: "Produtos", icon: "◆" },
  { id: "customers", label: "Clientes online", icon: "◎" },
  { id: "licenses", label: "Licenças", icon: "◇" },
  { id: "brands", label: "Rebrands", icon: "◫" },
  { id: "settings", label: "Configurações", icon: "⚙" },
  { id: "dlls", label: "DLLs privadas", icon: "▣" },
  { id: "resellers", label: "Revendedores", icon: "R" },
];

const sectionCopy: Record<Section, [string, string]> = {
  overview: [
    "Visão geral",
    "Tudo que está acontecendo nos seus produtos agora.",
  ],
  products: [
    "Produtos",
    "Controle disponibilidade e mensagens exibidas no Loader.",
  ],
  customers: [
    "Clientes online",
    "Acompanhe sessões e envie ações sem usar comandos.",
  ],
  licenses: ["Licenças", "Consulte validade, plano e último acesso."],
  brands: [
    "Rebrands",
    "Organize projetos diferentes dentro do mesmo painel.",
  ],
  dlls: [
    "DLLs privadas",
    "Publique versoes protegidas e libere links temporarios.",
  ],
  settings: [
    "Configurações",
    "Estado da integração e informações do sistema.",
  ],
  resellers: ["Revendedores", "Controle quem pode acessar o painel de revenda."],
};

function productName(product: ProductId) {
  return product === "legit" ? "Titan Legit" : "Titan Full";
}

function artifactProductName(product: ArtifactProduct) {
  return product === "loader" ? "Loader" : productName(product);
}

function relativeTime(timestamp: number) {
  const seconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  if (seconds < 10) return "agora";
  if (seconds < 60) return `há ${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `há ${minutes}min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `há ${hours}h`;
  return `há ${Math.floor(hours / 24)}d`;
}

function duration(seconds: number) {
  const safeSeconds = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(safeSeconds / 3600);
  const minutes = Math.floor((safeSeconds % 3600) / 60);
  if (hours >= 24) return `${Math.floor(hours / 24)}d ${hours % 24}h`;
  return `${hours}h ${minutes}min`;
}

function expiryText(expiry: number) {
  if (!expiry) return "Never";
  const remaining = expiry - Math.floor(Date.now() / 1000);
  if (remaining <= 0) return "Expirada";
  if (remaining > 10 * 365 * 86400) return "Never";
  const days = Math.floor(remaining / 86400);
  const hours = Math.floor((remaining % 86400) / 3600);
  return `${days}d ${hours}h`;
}

type Reseller = { discordId: string; username: string; displayName: string; role: string; active: number; createdAt: number; lastLogin: number };

export default function DashboardClient({ user }: { user: SiteUser }) {
  const [section, setSection] = useState<Section>("overview");
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [broadcast, setBroadcast] = useState("");
  const [search, setSearch] = useState("");
  const [adminRebrandFilter, setAdminRebrandFilter] = useState("all");
  const [busy, setBusy] = useState("");
  const [rebrands, setRebrands] = useState<Rebrand[]>([]);
  const [rebrandForm, setRebrandForm] = useState({
    name: "Nova marca",
    slug: "nova-marca",
    product: "both" as RebrandProduct,
    primaryColor: "#7c8cff",
    secondaryColor: "#131720",
    loaderTitle: "Nova marca",
    dllTitle: "Nova marca",
    logoUrl: "",
  });
  const [editingRebrandId, setEditingRebrandId] = useState<string | null>(null);
  const [lastRebrandToken, setLastRebrandToken] = useState("");
  const [artifactRebrandId, setArtifactRebrandId] = useState("");
  const [artifactProduct, setArtifactProduct] = useState<ProductId>("full");
  const [artifactFile, setArtifactFile] = useState<File | null>(null);
  const [artifactLink, setArtifactLink] = useState("");
  const [artifactBusy, setArtifactBusy] = useState(false);
  const [artifactProgress, setArtifactProgress] = useState(0);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [artifactLinkId, setArtifactLinkId] = useState("");
  const [artifactFilterRebrandId, setArtifactFilterRebrandId] = useState("all");
  const [baseProduct, setBaseProduct] = useState<ArtifactProduct>("full");
  const [baseFile, setBaseFile] = useState<File | null>(null);
  const [baseBusy, setBaseBusy] = useState(false);
  const [baseProgress, setBaseProgress] = useState(0);
  const [resellers, setResellers] = useState<Reseller[]>([]);
  const [resellerId, setResellerId] = useState("");
  const [resellerBusy, setResellerBusy] = useState(false);

  const loadDashboard = useCallback(async (quiet = false) => {
    if (!quiet) setRefreshing(true);
    try {
      const response = await fetch("/api/control", { cache: "no-store" });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error || "Falha ao carregar o painel.");
      }
      setData(payload);
      setError("");
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "O TitanBot está indisponível."
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
    const timer = window.setInterval(() => loadDashboard(true), 15000);
    return () => window.clearInterval(timer);
  }, [loadDashboard]);

  const loadRebrands = useCallback(async () => {
    try {
      const response = await fetch("/api/rebrands", { cache: "no-store" });
      const payload = await response.json();
      if (response.ok) setRebrands(payload.rebrands || []);
    } catch {
      // The dashboard can still operate while storage is being provisioned.
    }
  }, []);

  useEffect(() => {
    loadRebrands();
  }, [loadRebrands]);

  const loadArtifacts = useCallback(async () => {
    try {
      const response = await fetch("/api/artifacts", { cache: "no-store" });
      const payload = await response.json();
      if (response.ok) setArtifacts(payload.artifacts || []);
    } catch {
      // O painel continua funcionando se o armazenamento estiver indisponivel.
    }
  }, []);

  useEffect(() => {
    loadArtifacts();
  }, [loadArtifacts]);

  const loadResellers = useCallback(async () => {
    try {
      const response = await fetch("/api/admin/resellers", { cache: "no-store" });
      const payload = await response.json();
      if (response.ok) setResellers(payload.resellers || []);
    } catch { /* o painel continua utilizavel */ }
  }, []);

  useEffect(() => { loadResellers(); }, [loadResellers]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  async function performAction(
    key: string,
    payload: Record<string, unknown>,
    successMessage: string
  ) {
    setBusy(key);
    try {
      const response = await fetch("/api/control", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "A ação não foi concluída.");
      }
      setToast(successMessage);
      await loadDashboard(true);
      return true;
    } catch (actionError) {
      setToast(
        actionError instanceof Error
          ? actionError.message
          : "A ação não foi concluída."
      );
      return false;
    } finally {
      setBusy("");
    }
  }

  const filteredClients = useMemo(() => {
    const value = search.trim().toLowerCase();
    if (!data) return [];
    return data.clients.filter((client) => {
      const matchesRebrand = adminRebrandFilter === "all"
        || (adminRebrandFilter === "unassigned" ? !client.rebrandToken : client.rebrandToken === adminRebrandFilter);
      if (!matchesRebrand) return false;
      if (!value) return true;
      return [
        client.username,
        client.discordName,
        client.computer,
        productName(client.product),
      ].some((field) => field?.toLowerCase().includes(value));
    });
  }, [data, search, adminRebrandFilter]);

  const filteredLicenses = useMemo(() => {
    const value = search.trim().toLowerCase();
    if (!data) return [];
    return data.licenses.filter((license) => {
      const matchesRebrand = adminRebrandFilter === "all"
        || (adminRebrandFilter === "unassigned" ? !license.rebrandToken : license.rebrandToken === adminRebrandFilter);
      if (!matchesRebrand) return false;
      if (!value) return true;
      return [license.username, license.discordName, license.subscription].some(
        (field) => field?.toLowerCase().includes(value)
      );
    });
  }, [data, search, adminRebrandFilter]);

  const activeLicenses =
    data?.licenses.filter(
      (license) =>
        !license.licenseExpiry ||
        license.licenseExpiry > Math.floor(Date.now() / 1000)
    ).length || 0;
  const workingProducts = data
    ? Object.values(data.products).filter((product) => product.working).length
    : 0;

  async function sendBroadcast() {
    const message = broadcast.trim();
    if (!message) return;
    const success = await performAction(
      "broadcast",
      { operation: "broadcast", message, author: "Titan Control" },
      `Aviso enviado para ${data?.clients.length || 0} cliente(s).`
    );
    if (success) setBroadcast("");
  }

  function sendClientCommand(client: Client, action: string) {
    let message = "";
    if (action === "show_notification") {
      message = window.prompt(`Mensagem para ${client.username}:`)?.trim() || "";
      if (!message) return;
    }
    if (action === "kick_request") {
      message =
        window.prompt(`Motivo para desconectar ${client.username}:`)?.trim() ||
        "";
      if (!message) return;
    }
    if (
      action !== "show_notification" &&
      action !== "take_screenshot" &&
      !window.confirm(`Confirmar ação para ${client.username}?`)
    ) {
      return;
    }

    performAction(
      `command-${client.id}`,
      {
        operation: "client_command",
        clientId: client.id,
        action,
        message,
        reason: message,
        author: "Titan Control",
      },
      `Comando enviado para ${client.username}.`
    );
  }

  function ProductCard({ productId }: { productId: ProductId }) {
    const product = data?.products[productId];
    if (!product) return null;
    return (
      <article className="product-card">
        <div className={`product-orb ${productId}`}>
          {productId === "full" ? "F" : "L"}
        </div>
        <div className="product-card-main">
          <div className="product-title-row">
            <div>
              <span className="eyebrow">MTA:SA</span>
              <h3>{productName(productId)}</h3>
            </div>
            <span
              className={`status-pill ${
                product.working ? "status-working" : "status-disabled"
              }`}
            >
              <i />
              {product.working ? "Working" : "Disabled"}
            </span>
          </div>
          <div className="product-message">
            <span>Mensagem atual</span>
            <p>{product.message || "Nenhuma mensagem definida"}</p>
          </div>
          <div className="product-meta">
            <span>Atualizado {relativeTime(product.updatedAt)}</span>
            <span>por {product.updatedBy}</span>
          </div>
          <button
            className={product.working ? "button danger-soft" : "button primary"}
            disabled={busy === `product-${productId}`}
            onClick={() =>
              performAction(
                `product-${productId}`,
                {
                  operation: "product_status",
                  product: productId,
                  working: !product.working,
                  message: product.working
                    ? "Temporarily disabled"
                    : "Operational",
                  updatedBy: "Titan Control",
                },
                `${productName(productId)} foi ${
                  product.working ? "desativado" : "ativado"
                }.`
              )
            }
          >
            {busy === `product-${productId}`
              ? "Salvando..."
              : product.working
                ? "Colocar em manutenção"
                : "Ativar produto"}
          </button>
        </div>
      </article>
    );
  }

  function Overview() {
    return (
      <>
        <section className="welcome-panel">
          <div>
            <span className="eyebrow accent">TITAN SERVICES</span>
            <h2>Seu ecossistema, em um só lugar.</h2>
            <p>
              Controle produtos, clientes e comunicação sem precisar memorizar
              comandos do Discord.
            </p>
          </div>
          <div className="welcome-status">
            <div className="pulse-ring">
              <span>{data?.health.usersOnline || 0}</span>
            </div>
            <div>
              <strong>clientes online</strong>
              <small>sincronização automática</small>
            </div>
          </div>
          <div className="welcome-quick-actions">
            <button type="button" onClick={() => setSection("products")}>Gerenciar produtos</button>
            <button type="button" onClick={() => setSection("customers")}>Ver clientes</button>
          </div>
        </section>

        <section className="metric-grid">
          <article className="metric-card">
            <span className="metric-icon blue">◎</span>
            <div>
              <small>Online agora</small>
              <strong>{data?.health.usersOnline || 0}</strong>
              <span>sessões conectadas</span>
            </div>
          </article>
          <article className="metric-card">
            <span className="metric-icon violet">◇</span>
            <div>
              <small>Licenças ativas</small>
              <strong>{activeLicenses}</strong>
              <span>de {data?.licenses.length || 0} registradas</span>
            </div>
          </article>
          <article className="metric-card">
            <span className="metric-icon green">◆</span>
            <div>
              <small>Produtos ativos</small>
              <strong>{workingProducts}/2</strong>
              <span>disponíveis no Loader</span>
            </div>
          </article>
          <article className="metric-card">
            <span className="metric-icon amber">◫</span>
            <div>
              <small>Marcas</small>
              <strong>{rebrands.length}</strong>
              <span>rebrands configurados</span>
            </div>
          </article>
        </section>

        <section className="overview-grid">
          <div className="panel product-summary">
            <div className="panel-heading">
              <div>
                <span className="eyebrow">OPERAÇÃO</span>
                <h3>Saúde dos produtos</h3>
              </div>
              <div className="product-summary-actions">
                <span>{workingProducts}/2 ativos</span>
                <button className="text-button" onClick={() => setSection("products")}>Gerenciar</button>
              </div>
            </div>
            <div className="compact-products">
              <ProductCard productId="full" />
              <ProductCard productId="legit" />
            </div>
          </div>

          <div className="panel broadcast-panel">
            <div className="panel-heading">
              <div>
                <span className="eyebrow">COMUNICAÇÃO</span>
                <h3>Enviar aviso</h3>
              </div>
              <span className="mini-badge">Broadcast</span>
            </div>
            <p className="panel-copy">
              A mensagem aparece uma única vez para cada cliente conectado.
            </p>
            <textarea
              value={broadcast}
              maxLength={500}
              onChange={(event) => setBroadcast(event.target.value)}
              placeholder="Ex.: Atualização disponível. Reinicie o Loader."
            />
            <div className="input-footer">
              <span>{broadcast.length}/500</span>
              <button
                className="button primary"
                disabled={!broadcast.trim() || busy === "broadcast"}
                onClick={sendBroadcast}
              >
                {busy === "broadcast" ? "Enviando..." : "Enviar aviso"}
              </button>
            </div>
          </div>

          <div className="panel activity-panel">
            <div className="panel-heading">
              <div>
                <span className="eyebrow">HISTÓRICO</span>
                <h3>Atividade recente</h3>
              </div>
            </div>
            <div className="activity-list">
              {data?.activities.length ? (
                data.activities.slice(0, 6).map((activity) => (
                  <div className="activity-item" key={activity.id}>
                    <span className={`activity-dot ${activity.type}`} />
                    <div>
                      <strong>{activity.title}</strong>
                      <p>{activity.detail || "Ação concluída pelo painel."}</p>
                    </div>
                    <time>{relativeTime(activity.createdAt)}</time>
                  </div>
                ))
              ) : (
                <div className="empty-state compact">
                  <span>◌</span>
                  <p>As próximas ações feitas no painel aparecerão aqui.</p>
                </div>
              )}
            </div>
          </div>
        </section>
      </>
    );
  }

  function Products() {
    return (
      <section className="content-stack">
        <div className="section-intro">
          <div>
            <span className="eyebrow accent">CATÁLOGO PRINCIPAL</span>
            <h2>Disponibilidade em tempo real</h2>
            <p>
              Alterações são refletidas no Loader na próxima consulta ao
              servidor.
            </p>
          </div>
          <span className="sync-chip">Atualização a cada 15s</span>
        </div>
        <div className="product-control-summary">
          <article><span>OPERAÇÃO</span><strong>{workingProducts === 2 ? "Tudo operacional" : workingProducts === 1 ? "Operação parcial" : "Em manutenção"}</strong><small>{workingProducts}/2 produtos disponíveis</small></article>
          <article><span>CLIENTES AGORA</span><strong>{data?.health.usersOnline || 0}</strong><small>sessões conectadas</small></article>
          <article><span>SINCRONIZAÇÃO</span><strong>15 segundos</strong><small>consulta automática do Loader</small></article>
        </div>
        <div className="panel product-management-panel">
          <div className="panel-heading"><div><span className="eyebrow">GERENCIAMENTO</span><h3>Disponibilidade dos produtos</h3><p>Ative ou coloque um produto em manutenção. A mudança aparece no Loader automaticamente.</p></div><span className={`status-pill ${workingProducts === 2 ? "status-working" : "status-disabled"}`}><i />{workingProducts === 2 ? "Operacional" : "Atenção"}</span></div>
          <div className="product-page-grid">
            <ProductCard productId="full" />
            <ProductCard productId="legit" />
          </div>
        </div>
        <div className="product-page-footer">
          <div className="panel announcement-history">
            <div className="panel-heading">
              <div>
                <span className="eyebrow">ÚLTIMA COMUNICAÇÃO</span>
                <h3>Broadcast atual</h3>
              </div>
            </div>
            {data?.latestAnnouncement ? (
              <div className="announcement-row">
                <span className="announcement-icon">↗</span>
                <div>
                  <strong>{data.latestAnnouncement.message}</strong>
                  <p>Enviado {relativeTime(data.latestAnnouncement.createdAt)} · {data.latestAnnouncement.delivered} entrega(s)</p>
                </div>
              </div>
            ) : (
              <div className="empty-state inline"><span>◌</span><p>Nenhum broadcast enviado desde que o bot iniciou.</p></div>
            )}
          </div>
          <div className="panel product-update-note">
            <div className="panel-heading"><div><span className="eyebrow">COMO FUNCIONA</span><h3>Atualização automática</h3></div></div>
            <div className="product-update-flow"><span>1</span><p><strong>Você altera o status</strong>A configuração é salva imediatamente.</p><i /><span>2</span><p><strong>O Loader consulta</strong>Em até 15 segundos recebe o novo estado.</p><i /><span>3</span><p><strong>O cliente é informado</strong>Produto e mensagem aparecem atualizados.</p></div>
          </div>
        </div>
      </section>
    );
  }

  function Customers() {
    return (
      <section className="content-stack">
        {Toolbar({ count: `${filteredClients.length} online`, showRebrandFilter: true })}
        <div className="table-panel">
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Cliente</th>
                  <th>Produto</th>
                  <th>Plano</th>
                  <th>Expiração</th>
                  <th>Sessão</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredClients.map((client) => (
                  <tr key={client.id}>
                    <td>
                      <UserCell
                        username={client.username}
                        detail={client.discordName || "Discord não vinculado"}
                      />
                    </td>
                    <td>
                      <span className={`product-tag ${client.product}`}>
                        {productName(client.product)}
                      </span>
                    </td>
                    <td>{client.subscription || "Indisponível"}</td>
                    <td>{expiryText(client.licenseExpiry)}</td>
                    <td>
                      {duration((Date.now() - client.connectedAt) / 1000)}
                    </td>
                    <td>
                      <div className="row-actions">
                        <button
                          title="Notificar"
                          onClick={() =>
                            sendClientCommand(client, "show_notification")
                          }
                        >
                          ✦
                        </button>
                        <button
                          title="Screenshot"
                          onClick={() =>
                            sendClientCommand(client, "take_screenshot")
                          }
                        >
                          ◉
                        </button>
                        <button
                          title="Unload"
                          onClick={() =>
                            sendClientCommand(client, "unload_cheat")
                          }
                        >
                          ↙
                        </button>
                        <button
                          className="danger"
                          title="Desconectar"
                          onClick={() =>
                            sendClientCommand(client, "kick_request")
                          }
                        >
                          ×
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!filteredClients.length && (
            <EmptyState
              icon="◎"
              title="Nenhum cliente online"
              text="Eles aparecerão aqui assim que enviarem o heartbeat."
            />
          )}
        </div>
      </section>
    );
  }

  function Licenses() {
    return (
      <section className="content-stack">
        {Toolbar({ count: `${filteredLicenses.length} licença(s)`, showRebrandFilter: true })}
        <div className="table-panel">
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>Usuário</th>
                  <th>Produto</th>
                  <th>Plano</th>
                  <th>Status</th>
                  <th>Tempo restante</th>
                  <th>Último acesso</th>
                </tr>
              </thead>
              <tbody>
                {filteredLicenses.map((license) => {
                  const expired =
                    expiryText(license.licenseExpiry) === "Expirada";
                  return (
                    <tr key={`${license.product}:${license.username}`}>
                      <td>
                        <UserCell
                          username={license.username}
                          detail={
                            license.discordName || "Discord não vinculado"
                          }
                          muted
                        />
                      </td>
                      <td>
                        <span className={`product-tag ${license.product}`}>
                          {productName(license.product)}
                        </span>
                      </td>
                      <td>{license.subscription || "Indisponível"}</td>
                      <td>
                        <span
                          className={`status-pill small ${
                            expired ? "status-disabled" : "status-working"
                          }`}
                        >
                          <i />
                          {expired ? "Expirada" : "Ativa"}
                        </span>
                      </td>
                      <td>{expiryText(license.licenseExpiry)}</td>
                      <td>{relativeTime(license.lastSeen)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {!filteredLicenses.length && (
            <EmptyState
              icon="◇"
              title="Nenhuma licença encontrada"
              text="O histórico será preenchido quando os clientes conectarem."
            />
          )}
        </div>
      </section>
    );
  }

  function Toolbar({ count, showRebrandFilter = false }: { count: string; showRebrandFilter?: boolean }) {
    return (
      <div className="toolbar">
        <div className="toolbar-controls">
          <label className="search-box">
            <span>⌕</span>
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Buscar usuário, Discord ou produto"
            />
          </label>
          {showRebrandFilter && <label className="admin-filter-label"><span>REBRAND</span><select className="admin-filter-select" value={adminRebrandFilter} onChange={(event) => setAdminRebrandFilter(event.target.value)}><option value="all">Todos</option><option value="unassigned">Sem rebrand</option>{rebrands.map((rebrand) => <option key={rebrand.token} value={rebrand.token}>{rebrand.name}</option>)}</select></label>}
        </div>
        <span className="result-count">{count}</span>
      </div>
    );
  }

  function UserCell({
    username,
    detail,
    muted = false,
  }: {
    username: string;
    detail: string;
    muted?: boolean;
  }) {
    return (
      <div className="user-cell">
        <span className={`avatar ${muted ? "muted" : ""}`}>
          {username.slice(0, 2).toUpperCase()}
        </span>
        <div>
          <strong>{username}</strong>
          <small>{detail}</small>
        </div>
      </div>
    );
  }

  function EmptyState({
    icon,
    title,
    text,
  }: {
    icon: string;
    title: string;
    text: string;
  }) {
    return (
      <div className="empty-state">
        <span>{icon}</span>
        <h3>{title}</h3>
        <p>{text}</p>
      </div>
    );
  }

  function Brands() {
    function startNewRebrand() {
      setEditingRebrandId(null);
      setLastRebrandToken("");
      setRebrandForm({ name: "Nova marca", slug: "nova-marca", product: "both", primaryColor: "#7c8cff", secondaryColor: "#131720", loaderTitle: "Nova marca", dllTitle: "Nova marca", logoUrl: "" });
    }

    function editRebrand(item: Rebrand) {
      setEditingRebrandId(item.id);
      setLastRebrandToken("");
      setRebrandForm({ name: item.name, slug: item.slug, product: "both", primaryColor: item.primaryColor, secondaryColor: item.secondaryColor, loaderTitle: item.loaderTitle, dllTitle: item.dllTitle, logoUrl: item.logoUrl });
    }

    async function saveRebrand(event: FormEvent<HTMLFormElement>) {
      event.preventDefault();
      setBusy("rebrand");
      setLastRebrandToken("");
      try {
        const response = await fetch("/api/rebrands", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ ...rebrandForm, id: editingRebrandId || undefined }),
        });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "Não foi possível salvar o rebrand.");
        setLastRebrandToken(payload.token || "");
        setToast(payload.created ? "Rebrand criado." : "Rebrand atualizado.");
        await loadRebrands();
      } catch (saveError) {
        setToast(saveError instanceof Error ? saveError.message : "Falha ao salvar o rebrand.");
      } finally {
        setBusy("");
      }
    }

    async function deleteRebrand(id: string) {
      if (!window.confirm("Excluir este rebrand? O token deixará de funcionar.")) return;
      try {
        const response = await fetch("/api/rebrands", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ id }) });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "Não foi possível excluir o rebrand.");
        if (editingRebrandId === id) startNewRebrand();
        setToast("Rebrand excluído.");
        await loadRebrands();
      } catch (deleteError) {
        setToast(deleteError instanceof Error ? deleteError.message : "Falha ao excluir o rebrand.");
      }
    }

    async function rotateRebrandToken(id: string) {
      try {
        const item = rebrands.find((entry) => entry.id === id);
        if (!item) return;
        const response = await fetch("/api/rebrands", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id, name: item.name, slug: item.slug, product: "both", primaryColor: item.primaryColor, secondaryColor: item.secondaryColor, loaderTitle: item.loaderTitle, dllTitle: item.dllTitle, logoUrl: item.logoUrl, rotateToken: true }) });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "Não foi possível gerar o token.");
        setLastRebrandToken(payload.token || "");
        setToast("Novo token gerado. Substitua o token no loader.");
        await loadRebrands();
      } catch (rotateError) {
        setToast(rotateError instanceof Error ? rotateError.message : "Falha ao gerar o token.");
      }
    }

    return (
      <section className="content-stack">
        <div className="brand-hero">
          <div className="brand-mark">T</div>
          <div>
            <span className="eyebrow accent">MARCA PRINCIPAL</span>
            <h2>Titan Services</h2>
            <p>Estrutura pronta para receber produtos e projetos de rebrand.</p>
          </div>
          <span className="status-pill status-working">
            <i />
            Ativa
          </span>
        </div>
        <div className="brand-grid">
          <article className="panel brand-detail">
            <span className="eyebrow">PRODUTOS</span>
            <strong>2</strong>
            <p>Titan Full e Titan Legit</p>
          </article>
          <article className="panel brand-detail">
            <span className="eyebrow">CLIENTES ONLINE</span>
            <strong>{data?.clients.length || 0}</strong>
            <p>em todos os produtos</p>
          </article>
          <article className="panel brand-detail">
            <span className="eyebrow">LICENÇAS</span>
            <strong>{data?.licenses.length || 0}</strong>
            <p>registradas no histórico</p>
          </article>
        </div>
        <div className="panel rebrand-workspace">
          <div className="panel-heading">
            <div>
              <span className="eyebrow accent">IDENTIDADE REMOTA</span>
              <h3>Editar aparência</h3>
              <p>Salve nome e textos que os clientes verão no próximo acesso.</p>
            </div>
            <div className="rebrand-heading-actions"><span className="status-pill status-working"><i />Configuração segura</span><button className="text-button" type="button" onClick={startNewRebrand}>Novo rebrand</button></div>
          </div>
          <div className="rebrand-editor-grid">
            <form className="rebrand-form" onSubmit={saveRebrand}>
              <div className="form-section-title">Identificação <small>Como o projeto aparece no painel.</small></div>
              <label>Nome da marca<input value={rebrandForm.name} onChange={(event) => setRebrandForm({ ...rebrandForm, name: event.target.value })} /></label>
              <label>Identificador interno<input value={rebrandForm.slug} onChange={(event) => setRebrandForm({ ...rebrandForm, slug: event.target.value })} /></label>
              <div className="form-section-title">Textos <small>O que o cliente verá no loader e na DLL.</small></div>
              <label>Nome no loader<input value={rebrandForm.loaderTitle} onChange={(event) => setRebrandForm({ ...rebrandForm, loaderTitle: event.target.value })} /></label>
              <label>Nome dentro da DLL<input value={rebrandForm.dllTitle} onChange={(event) => setRebrandForm({ ...rebrandForm, dllTitle: event.target.value })} /></label>
              <label className="wide-field">URL do logo<input placeholder="https://..." value={rebrandForm.logoUrl} onChange={(event) => setRebrandForm({ ...rebrandForm, logoUrl: event.target.value })} /></label>
              <div className="rebrand-actions"><button className="button primary" type="submit" disabled={busy === "rebrand"}>{busy === "rebrand" ? "Salvando..." : editingRebrandId ? "Atualizar identidade" : "Criar identidade"}</button>{lastRebrandToken && <code className="token-result">Token gerado: {lastRebrandToken}</code>}</div>
            </form>
            <aside className="rebrand-preview">
              <div className="preview-label">PRÉVIA AO VIVO</div>
              <div className="preview-loader-card">
                <span className="preview-dot" />
                <div><small>LOADER</small><strong>{rebrandForm.loaderTitle || "Nome do loader"}</strong></div>
              </div>
              <div className="preview-dll-card">
                <small>INTERFACE DA DLL</small><strong>{rebrandForm.dllTitle || "Nome da DLL"}</strong><span>Working</span>
              </div>
              <div className="preview-products"><span>{rebrandForm.name || "Marca"} Menu</span><span>{rebrandForm.name || "Marca"} Legit</span></div>
            </aside>
          </div>
        </div>
        <section className="panel saved-rebrands">
          <div className="saved-rebrands-toolbar">
            <div><span className="eyebrow">PROJETOS SALVOS</span><h3>Seus rebrands</h3><p>Escolha um projeto para editar ou copiar o token usado pelo loader.</p></div>
            <div className="saved-rebrands-count"><strong>{rebrands.length}</strong><span>ativos</span></div>
          </div>
          {rebrands.length === 0 ? <div className="saved-rebrands-empty"><span>+</span><strong>Nenhum rebrand criado</strong><p>Use o formulário acima para criar sua primeira identidade.</p></div> : <div className="saved-rebrand-list">{rebrands.map((item) => <article key={item.id} className={`saved-rebrand${editingRebrandId === item.id ? " selected" : ""}`}>
            <div className="saved-rebrand-top">
              <button className="saved-rebrand-identity" type="button" onClick={() => editRebrand(item)} aria-label={`Editar ${item.name}`}>
                <span className="saved-rebrand-avatar">{item.name.trim().slice(0, 2).toUpperCase()}</span>
                <span className="saved-rebrand-copy"><strong>{item.name}</strong><small>{item.slug}</small></span>
              </button>
              <div className="saved-rebrand-badges"><span>Full + Legit</span><span>v{item.version}</span></div>
              <span className="status-pill status-working"><i />{editingRebrandId === item.id ? "Editando" : "Ativo"}</span>
            </div>
            <div className="saved-rebrand-bottom">
              <div className="saved-rebrand-token"><span>Token de conexão</span><code>{item.token || "Token antigo indisponível"}</code></div>
              <div className="saved-rebrand-actions">{item.token ? <button className="text-button" type="button" onClick={() => navigator.clipboard.writeText(item.token)}>Copiar token</button> : <button className="text-button" type="button" onClick={() => rotateRebrandToken(item.id)}>Gerar token</button>}<button className="text-button" type="button" onClick={() => editRebrand(item)}>Editar</button><button className="danger-text-button" type="button" onClick={() => deleteRebrand(item.id)}>Excluir</button></div>
            </div>
          </article>)}</div>}
        </section>
        <div className="panel roadmap-panel">
          <div>
            <span className="eyebrow">PRÓXIMA ETAPA</span>
            <h3>Central de rebrands</h3>
            <p>
              O próximo módulo permitirá criar marcas, separar clientes e
              adicionar administradores para cada projeto.
            </p>
          </div>
          <div className="roadmap-steps">
            <span className="done">1</span>
            <i />
            <span>2</span>
            <i />
            <span>3</span>
          </div>
        </div>
      </section>
    );
  }

  async function addReseller(event: FormEvent) {
    event.preventDefault();
    const id = resellerId.trim();
    if (!id) return;
    setResellerBusy(true);
    try {
      const response = await fetch("/api/admin/resellers", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ discordId: id }) });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Nao foi possivel adicionar.");
      setResellerId("");
      await loadResellers();
      setToast("Revendedor adicionado.");
    } catch (actionError) {
      setToast(actionError instanceof Error ? actionError.message : "Nao foi possivel adicionar.");
    } finally { setResellerBusy(false); }
  }

  async function removeReseller(discordId: string) {
    if (!window.confirm("Remover este revendedor?")) return;
    try {
      const response = await fetch("/api/admin/resellers", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ discordId }) });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Nao foi possivel remover.");
      await loadResellers();
      setToast("Revendedor removido.");
    } catch (actionError) { setToast(actionError instanceof Error ? actionError.message : "Nao foi possivel remover."); }
  }

  function Resellers() {
    const activeResellers = resellers.filter((item) => item.active).length;
    const loggedResellers = resellers.filter((item) => item.lastLogin > 0).length;
    const resellerDate = (value: number) => value ? new Date(value * 1000).toLocaleDateString("pt-BR") : "Ainda não acessou";
    return <section className="content-stack"><div className="section-intro reseller-admin-intro"><div><span className="eyebrow accent">ACESSO DA EQUIPE</span><h2>Revendedores</h2><p>Controle quem pode criar rebrands e acompanhar os próprios clientes e licenças. Seus arquivos privados continuam restritos ao administrador.</p></div><span className="status-pill status-working"><i />Acesso protegido</span></div><div className="reseller-admin-metrics"><article><span>Total</span><strong>{resellers.length}</strong><small>revendedores cadastrados</small></article><article><span>Ativos</span><strong>{activeResellers}</strong><small>com acesso liberado</small></article><article><span>Já acessaram</span><strong>{loggedResellers}</strong><small>contas confirmadas</small></article></div><div className="reseller-admin-grid"><div className="panel reseller-admin-panel"><div className="panel-heading"><div><span className="eyebrow">NOVO ACESSO</span><h3>Adicionar revendedor</h3><p>Informe o ID da conta que receberá acesso.</p></div></div><form className="reseller-access-form" onSubmit={addReseller}><label><span>ID DO DISCORD</span><input value={resellerId} onChange={(event) => setResellerId(event.target.value)} placeholder="Ex.: 1243893990407802985" inputMode="numeric" /></label><button className="button primary" type="submit" disabled={resellerBusy}>{resellerBusy ? "Adicionando..." : "Conceder acesso"}</button></form><div className="reseller-access-note"><span>i</span><p>O revendedor precisa estar no servidor Discord configurado. Depois disso, basta entrar pelo botão de login do site.</p></div></div><div className="panel reseller-directory"><div className="panel-heading"><div><span className="eyebrow">EQUIPE AUTORIZADA</span><h3>{resellers.length} revendedor(es)</h3><p>Visualize contas, último acesso e permissão atual.</p></div><span className="result-count">{activeResellers} ativo(s)</span></div>{resellers.length ? <div className="table-wrap"><table className="reseller-admin-table"><thead><tr><th>Revendedor</th><th>Discord ID</th><th>Último acesso</th><th>Status</th><th>Ação</th></tr></thead><tbody>{resellers.map((item) => <tr key={item.discordId}><td><div className="user-cell"><span className="avatar">{(item.displayName || item.username).slice(0, 2).toUpperCase()}</span><div><strong>{item.displayName || item.username}</strong><small>@{item.username}</small></div></div></td><td><code className="discord-id-cell">{item.discordId}</code></td><td>{resellerDate(item.lastLogin)}</td><td><span className={`status-pill ${item.active ? "status-working" : "status-disabled"}`}><i />{item.active ? "Ativo" : "Inativo"}</span></td><td><button className="danger-text-button" type="button" onClick={() => removeReseller(item.discordId)}>Remover</button></td></tr>)}</tbody></table></div> : <div className="reseller-directory-empty"><span>R</span><strong>Nenhum revendedor adicionado</strong><p>Use o formulário ao lado para liberar o primeiro acesso.</p></div>}</div></div></section>;
  }

  function Dlls() {
    const selectedRebrand = rebrands.find((item) => item.id === artifactRebrandId);
    const visibleArtifacts = artifacts.filter((artifact) => artifactFilterRebrandId === "all" || artifact.rebrandId === artifactFilterRebrandId);

    function formatSize(size: number) {
      if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} KB`;
      return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    }

    async function uploadDll() {
      if (!artifactFile || !artifactRebrandId) {
        setToast("Escolha o rebrand e a DLL.");
        return;
      }
      setArtifactBusy(true);
      setArtifactLink("");
      setArtifactProgress(0);
      try {
        const readPayload = async (response: Response, fallback: string) => {
          const text = await response.text();
          try {
            return JSON.parse(text) as Record<string, any>;
          } catch {
            throw new Error(response.status === 413 ? "O servidor recusou o bloco. Tente novamente; o upload foi reduzido automaticamente." : fallback);
          }
        };
        const chunkSize = 256 * 1024;
        const totalParts = Math.ceil(artifactFile.size / chunkSize);
        const initForm = new FormData();
        initForm.set("action", "init");
        initForm.set("rebrandId", artifactRebrandId);
        initForm.set("product", artifactProduct);
        initForm.set("fileName", artifactFile.name);
        initForm.set("contentType", artifactFile.type || "application/octet-stream");
        initForm.set("size", String(artifactFile.size));
        const initResponse = await fetch("/api/artifacts/upload", { method: "POST", body: initForm });
        const init = await readPayload(initResponse, "Falha ao iniciar o upload.");
        if (!initResponse.ok) throw new Error(init.error || "Falha ao iniciar o upload.");
        const parts: Array<{ partNumber: number; etag: string }> = [];
        for (let index = 0; index < totalParts; index += 1) {
          const partForm = new FormData();
          partForm.set("action", "part");
          partForm.set("uploadId", init.uploadId);
          partForm.set("partNumber", String(index + 1));
          partForm.set("part", artifactFile.slice(index * chunkSize, Math.min((index + 1) * chunkSize, artifactFile.size)), artifactFile.name);
          const partResponse = await fetch("/api/artifacts/upload", { method: "POST", body: partForm });
          const part = await readPayload(partResponse, `Falha no bloco ${index + 1}.`);
          if (!partResponse.ok) throw new Error(part.error || `Falha no bloco ${index + 1}.`);
          parts.push({ partNumber: index + 1, etag: part.etag });
          setArtifactProgress(Math.round(((index + 1) / totalParts) * 100));
        }
        const completeForm = new FormData();
        completeForm.set("action", "complete");
        completeForm.set("uploadId", init.uploadId);
        completeForm.set("parts", JSON.stringify(parts));
        const response = await fetch("/api/artifacts/upload", { method: "POST", body: completeForm });
        const payload = await readPayload(response, "Falha ao finalizar o upload.");
        if (!response.ok) throw new Error(payload.error || "Falha ao finalizar o upload.");
        setArtifactFile(null);
        await loadArtifacts();
        setToast("DLL publicada no armazenamento privado.");
      } catch (uploadError) {
        setToast(uploadError instanceof Error ? uploadError.message : "Falha ao publicar a DLL.");
      } finally {
        setArtifactBusy(false);
        setArtifactProgress(0);
      }
    }

    async function uploadBaseDll() {
      if (!baseFile) { setToast("Escolha a DLL base."); return; }
      setBaseBusy(true);
      setBaseProgress(0);
      try {
        const chunkSize = 256 * 1024;
        const totalParts = Math.ceil(baseFile.size / chunkSize);
        const initForm = new FormData();
        initForm.set("action", "init");
        initForm.set("rebrandId", "__base__");
        initForm.set("product", baseProduct);
        initForm.set("fileName", baseFile.name);
        initForm.set("contentType", baseFile.type || "application/octet-stream");
        initForm.set("size", String(baseFile.size));
        const initResponse = await fetch("/api/artifacts/upload", { method: "POST", body: initForm });
        const initText = await initResponse.text();
        const init = JSON.parse(initText) as Record<string, any>;
        if (!initResponse.ok) throw new Error(init.error || "Falha ao iniciar o upload base.");
        const parts: Array<{ partNumber: number; etag: string }> = [];
        for (let index = 0; index < totalParts; index += 1) {
          const partForm = new FormData();
          partForm.set("action", "part");
          partForm.set("uploadId", init.uploadId);
          partForm.set("partNumber", String(index + 1));
          partForm.set("part", baseFile.slice(index * chunkSize, Math.min((index + 1) * chunkSize, baseFile.size)), baseFile.name);
          const partResponse = await fetch("/api/artifacts/upload", { method: "POST", body: partForm });
          const part = JSON.parse(await partResponse.text()) as Record<string, any>;
          if (!partResponse.ok) throw new Error(part.error || `Falha no bloco ${index + 1}.`);
          parts.push({ partNumber: index + 1, etag: String(part.etag || "") });
          setBaseProgress(Math.round(((index + 1) / totalParts) * 100));
        }
        const completeForm = new FormData();
        completeForm.set("action", "complete");
        completeForm.set("uploadId", init.uploadId);
        completeForm.set("parts", JSON.stringify(parts));
        const completeResponse = await fetch("/api/artifacts/upload", { method: "POST", body: completeForm });
        const complete = JSON.parse(await completeResponse.text()) as Record<string, any>;
        if (!completeResponse.ok) throw new Error(complete.error || "Falha ao finalizar a DLL base.");
        const previous = artifacts.filter((item) => item.rebrandId === "__base__" && item.product === baseProduct);
        await Promise.all(previous.map((item) => fetch("/api/artifacts", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ artifactId: item.id }) })));
        setBaseFile(null);
        await loadArtifacts();
        setToast(`${artifactProductName(baseProduct)} base atualizado.`);
      } catch (uploadError) {
        setToast(uploadError instanceof Error ? uploadError.message : "Falha ao publicar a DLL base.");
      } finally { setBaseBusy(false); setBaseProgress(0); }
    }

    async function releaseDll(artifactId: string) {
      setArtifactLinkId(artifactId);
      try {
        const response = await fetch("/api/artifacts/link", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ artifactId, expiresIn: 600 }) });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "Falha ao liberar o download.");
        setArtifactLink(payload.url || "");
        setToast("Link temporario liberado por 10 minutos.");
      } catch (releaseError) {
        setToast(releaseError instanceof Error ? releaseError.message : "Falha ao liberar o download.");
      } finally {
        setArtifactLinkId("");
      }
    }

    async function deleteDll(artifactId: string) {
      if (!window.confirm("Excluir esta versao privada? Links antigos deixarao de funcionar.")) return;
      try {
        const response = await fetch("/api/artifacts", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ artifactId }) });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "Falha ao excluir a DLL.");
        setArtifactLink("");
        await loadArtifacts();
        setToast("Versao excluida.");
      } catch (deleteError) {
        setToast(deleteError instanceof Error ? deleteError.message : "Falha ao excluir a DLL.");
      }
    }

    return (
      <section className="content-stack dll-management">
        <div className="section-intro">
          <div><span className="eyebrow accent">DISTRIBUICAO SEGURA</span><h2>Gerenciamento de DLL</h2><p>Envie uma versao privada, acompanhe os arquivos e libere um link curto somente apos aprovar o cliente.</p></div>
          <span className="status-pill status-working"><i />R2 privado</span>
        </div>
        <div className="metric-grid">
          <article className="metric-card"><span className="metric-icon violet">DLL</span><div><small>Versoes privadas</small><strong>{artifacts.length}</strong><span>armazenadas</span></div></article>
          <article className="metric-card"><span className="metric-icon green">10m</span><div><small>Validade do link</small><strong>10m</strong><span>por liberacao</span></div></article>
          <article className="metric-card"><span className="metric-icon blue">0</span><div><small>Arquivo publico</small><strong>0</strong><span>nenhuma DLL exposta</span></div></article>
        </div>
        <div className="panel artifact-workspace base-dll-workspace">
          <div className="panel-heading"><div><span className="eyebrow accent">BIBLIOTECA GLOBAL</span><h3>Arquivos base dos produtos</h3><p>Mantenha as DLLs Full/Legit e o Loader padrão. O painel gera automaticamente um pacote com o token correto para cada revendedor.</p></div><span className="status-pill status-working"><i />Somente administrador</span></div>
          <div className="artifact-form">
            <label>Arquivo base<select value={baseProduct} onChange={(event) => setBaseProduct(event.target.value as ArtifactProduct)}><option value="full">Titan Full</option><option value="legit">Titan Legit</option><option value="loader">Loader padrão</option></select></label>
            <label>{baseProduct === "loader" ? "Loader.exe" : "DLL base"}<input type="file" accept={baseProduct === "loader" ? ".exe,.bin" : ".dll,.zip,.bin"} onChange={(event) => setBaseFile(event.currentTarget.files?.[0] || null)} />{baseFile && <small className="artifact-selected-file">Selecionado: {baseFile.name} · {(baseFile.size / (1024 * 1024)).toFixed(1)} MB</small>}</label>
            <button className="button primary" type="button" onClick={uploadBaseDll} disabled={baseBusy}>{baseBusy ? `Atualizando ${baseProgress}%` : `Atualizar ${baseProduct === "loader" ? "Loader" : "DLL base"}`}</button>
          </div>
          <p className="panel-copy">Base atual: <strong>{artifacts.find((item) => item.rebrandId === "__base__" && item.product === baseProduct)?.fileName || "nenhuma publicada"}</strong></p>
        </div>
        <div className="panel artifact-workspace">
          <div className="panel-heading"><div><span className="eyebrow accent">NOVA VERSAO</span><h3>Publicar DLL privada</h3><p>O arquivo fica no R2 e nao e acessivel sem um link emitido por voce.</p></div><span className="status-pill status-working"><i />Protegido</span></div>
          <div className="artifact-form">
            <label>Rebrand<select value={artifactRebrandId} onChange={(event) => setArtifactRebrandId(event.target.value)}><option value="">{rebrands.length ? "Selecione..." : "Nenhum rebrand criado"}</option>{rebrands.map((item) => <option key={item.id} value={item.id}>{item.name} · Full + Legit</option>)}</select></label>
            <label>Produto<select value={artifactProduct} onChange={(event) => setArtifactProduct(event.target.value as ProductId)}><option value="full">Titan Full</option><option value="legit">Titan Legit</option></select></label>
            <label>Arquivo DLL<input type="file" accept=".dll,.zip,.bin" onChange={(event) => setArtifactFile(event.currentTarget.files?.[0] || null)} />{artifactFile && <small className="artifact-selected-file">Selecionado: {artifactFile.name} · {(artifactFile.size / (1024 * 1024)).toFixed(1)} MB</small>}</label>
            <button className="button primary" type="button" onClick={uploadDll} disabled={artifactBusy}>{artifactBusy ? `Enviando ${artifactProgress}%` : "Publicar versao"}</button>
          </div>
          {selectedRebrand && <p className="panel-copy">Destino: <strong>{selectedRebrand.name}</strong>. A versao fica disponivel para Full e Legit.</p>}
          {artifactLink && <div className="artifact-link"><span>Link liberado por 10 min:</span><input readOnly value={artifactLink} onFocus={(event) => event.currentTarget.select()} /><button className="button" type="button" onClick={() => navigator.clipboard.writeText(artifactLink)}>Copiar</button></div>}
        </div>
        <div className="panel artifact-list-panel">
          <div className="artifact-filter-row"><div><span className="eyebrow">VERSOES PUBLICADAS</span><h3>Arquivos privados</h3><p>Libere uma versao apenas quando o cliente estiver aprovado.</p></div><label className="admin-filter-label"><span>FILTRAR POR REBRAND</span><select className="admin-filter-select" value={artifactFilterRebrandId} onChange={(event) => setArtifactFilterRebrandId(event.target.value)}><option value="all">Todos os rebrands</option><option value="__base__">Biblioteca global</option>{rebrands.map((rebrand) => <option key={rebrand.id} value={rebrand.id}>{rebrand.name}</option>)}</select></label><span className="result-count">{visibleArtifacts.length} arquivo(s)</span></div>
          {visibleArtifacts.length ? <div className="artifact-list">{visibleArtifacts.map((artifact) => <article className="artifact-row" key={artifact.id}><div className="artifact-file-icon">{artifact.product === "loader" ? "EXE" : "DLL"}</div><div className="artifact-row-main"><strong>{artifact.fileName}</strong><small>{artifact.rebrandId === "__base__" ? "Base global" : rebrands.find((item) => item.id === artifact.rebrandId)?.name || "Rebrand removido"} · {artifactProductName(artifact.product)} · {formatSize(artifact.size)} · {new Date(artifact.createdAt * 1000).toLocaleString("pt-BR")}</small></div><div className="artifact-row-actions">{artifact.product !== "loader" && <button className="button primary" type="button" onClick={() => releaseDll(artifact.id)} disabled={artifactLinkId === artifact.id}>{artifactLinkId === artifact.id ? "Liberando..." : "Liberar 10 min"}</button>}<button className="danger-text-button" type="button" onClick={() => deleteDll(artifact.id)}>Excluir</button></div></article>)}</div> : <EmptyState icon="DLL" title={artifactFilterRebrandId === "all" ? "Nenhum arquivo publicado" : "Nenhum arquivo neste rebrand"} text="Envie uma versao acima para comecar." />}
        </div>
      </section>
    );
  }

  function Settings() {
    return (
      <section className="settings-grid">
        <article className="panel settings-card">
          <div className="settings-icon connected">⌁</div>
          <div>
            <span className="eyebrow">INTEGRAÇÃO</span>
            <h3>TitanBot</h3>
            <p>Servidor conectado e respondendo normalmente.</p>
          </div>
          <span className="status-pill status-working">
            <i />
            Conectado
          </span>
        </article>
        <article className="panel settings-card">
          <div className="settings-icon">↻</div>
          <div>
            <span className="eyebrow">SINCRONIZAÇÃO</span>
            <h3>Atualização automática</h3>
            <p>O painel busca dados novos a cada 15 segundos.</p>
          </div>
          <strong>15s</strong>
        </article>
        <article className="panel system-card">
          <div className="panel-heading">
            <div>
              <span className="eyebrow">SISTEMA</span>
              <h3>Informações do serviço</h3>
            </div>
          </div>
          <dl>
            <div>
              <dt>Versão do bot</dt>
              <dd>v{data?.health.version || "—"}</dd>
            </div>
            <div>
              <dt>Tempo online</dt>
              <dd>{duration(data?.health.uptimeSeconds || 0)}</dd>
            </div>
            <div>
              <dt>Memória utilizada</dt>
              <dd>{data?.health.memoryMb || 0} MB</dd>
            </div>
            <div>
              <dt>Conexão</dt>
              <dd>Protegida no servidor</dd>
            </div>
          </dl>
        </article>
      </section>
    );
  }

  function content() {
    if (error && !data) {
      return (
        <div className="connection-error">
          <span>!</span>
          <h2>Não foi possível conectar ao TitanBot</h2>
          <p>{error}</p>
          <button className="button primary" onClick={() => loadDashboard()}>
            Tentar novamente
          </button>
        </div>
      );
    }
    if (loading) {
      return (
        <div className="loading-view">
          <span className="loading-bar" />
          <p>Organizando seus produtos...</p>
        </div>
      );
    }
    if (section === "products") return Products();
    if (section === "customers") return Customers();
    if (section === "licenses") return Licenses();
    if (section === "brands") return Brands();
    if (section === "dlls") return Dlls();
    if (section === "resellers") return Resellers();
    if (section === "settings") return Settings();
    return Overview();
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="logo-lockup">
          <div className="logo-mark">T</div>
          <div>
            <strong>Titan</strong>
            <span>Control</span>
          </div>
        </div>
        <nav aria-label="Navegação principal">
          <span className="nav-label">PAINEL</span>
          {navigation.filter((item) => ["overview", "products", "customers", "licenses"].includes(item.id)).map((item) => (
            <button
              className={section === item.id ? "active" : ""}
              key={item.id}
              onClick={() => {
                setSection(item.id);
                setSearch("");
              }}
            >
              <span>{item.icon}</span>
              {item.label}
              {item.id === "customers" && data?.clients.length ? (
                <small>{data.clients.length}</small>
              ) : null}
            </button>
          ))}
          <span className="nav-label spaced">GESTÃO</span>
          {navigation.filter((item) => ["brands", "dlls", "settings", "resellers"].includes(item.id)).map((item) => (
            <button
              className={section === item.id ? "active" : ""}
              key={item.id}
              onClick={() => {
                setSection(item.id);
                setSearch("");
              }}
            >
              <span>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="profile-avatar">{user.displayName.slice(0, 2).toUpperCase()}</div>
          <div>
            <strong>{user.displayName}</strong>
            <span>Administrador</span>
          </div>
          <a className="profile-logout" href="/api/auth/logout">Sair</a>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <h1>{sectionCopy[section][0]}</h1>
            <p>{sectionCopy[section][1]}</p>
          </div>
          <div className="topbar-actions">
            <a className="preview-link" href="/?preview=reseller" target="_blank" rel="noreferrer">Testar revendedor ↗</a>
            <div className="connection-chip">
              <i className={error ? "offline" : ""} />
              <span>{error ? "Reconectando" : "Bot conectado"}</span>
            </div>
            <button
              className={`refresh-button ${refreshing ? "spinning" : ""}`}
              aria-label="Atualizar painel"
              onClick={() => loadDashboard()}
            >
              ↻
            </button>
          </div>
        </header>
        <div className="page-content">{content()}</div>
      </main>

      <nav className="mobile-nav" aria-label="Navegação móvel">
        {navigation.map((item) => (
          <button
            className={section === item.id ? "active" : ""}
            key={item.id}
            onClick={() => setSection(item.id)}
          >
            <span>{item.icon}</span>
            <small>{item.label.split(" ")[0]}</small>
          </button>
        ))}
      </nav>

      {toast && (
        <div className="toast" role="status">
          <span>✓</span>
          {toast}
        </div>
      )}
    </div>
  );
}
