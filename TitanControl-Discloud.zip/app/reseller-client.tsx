"use client";

import { useEffect, useState } from "react";
import type { SiteUser } from "./auth-types";

type Product = "full" | "legit";
type ResellerTab = "rebrands" | "customers" | "licenses";
type ResellerData = { clients: Array<{ username: string; discordName: string; computer: string; product: Product; online?: boolean }>; licenses: Array<{ username: string; product: Product; subscription: string; licenseExpiry: number }> };
type Rebrand = { id: string; name: string; slug: string; loaderTitle: string; dllTitle: string; token: string; updatedAt: number };

function productName(value: string) { return value === "legit" ? "Titan Legit" : "Titan Full"; }
function expiry(value: number) { if (!value) return "Never"; const seconds = value - Math.floor(Date.now() / 1000); if (seconds <= 0) return "Expirada"; return `${Math.floor(seconds / 86400)}d ${Math.floor((seconds % 86400) / 3600)}h`; }

export default function ResellerClient({ user, preview = false }: { user: SiteUser; preview?: boolean }) {
  const [activeTab, setActiveTab] = useState<ResellerTab>("rebrands");
  const [data, setData] = useState<ResellerData | null>(null);
  const [rebrands, setRebrands] = useState<Rebrand[]>([]);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [busy, setBusy] = useState(false);
  const [downloadingId, setDownloadingId] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", loaderTitle: "", dllTitle: "" });

  async function load() {
    try {
      const [dashboardResponse, brandsResponse] = await Promise.all([fetch("/api/control", { cache: "no-store" }), fetch("/api/rebrands", { cache: "no-store" })]);
      const dashboard = await dashboardResponse.json();
      const brands = await brandsResponse.json();
      if (!dashboardResponse.ok) throw new Error(dashboard.error || "Não foi possível carregar o painel.");
      if (!brandsResponse.ok) throw new Error(brands.error || "Não foi possível carregar os rebrands.");
      setData(dashboard); setRebrands(brands.rebrands || []); setError("");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Não foi possível carregar o painel."); }
  }

  useEffect(() => {
    if (preview) {
      setData({ clients: [{ username: "cliente_demo", discordName: "Demo User", computer: "PC-TESTE", product: "full" }], licenses: [{ username: "cliente_demo", product: "full", subscription: "Platina", licenseExpiry: Math.floor(Date.now() / 1000) + 32 * 86400 }] });
      setRebrands([{ id: "preview-brand", name: "Lunar", slug: "lunar", loaderTitle: "Lunar Loader", dllTitle: "Lunar Menu", token: "TS-TOKEN-DE-TESTE", updatedAt: Date.now() }]);
      return;
    }
    load();
  }, [preview]);
  useEffect(() => { if (!toast) return; const timer = window.setTimeout(() => setToast(""), 3600); return () => window.clearTimeout(timer); }, [toast]);

  function startEdit(item: Rebrand) { setEditingId(item.id); setForm({ name: item.name, loaderTitle: item.loaderTitle || item.name, dllTitle: item.dllTitle || item.name }); window.scrollTo({ top: 190, behavior: "smooth" }); }
  function resetForm() { setEditingId(null); setForm({ name: "", loaderTitle: "", dllTitle: "" }); }

  async function saveRebrand(event: React.FormEvent) {
    event.preventDefault();
    if (!form.name.trim()) { setToast("Informe o nome do rebrand."); return; }
    setBusy(true);
    try {
      const wasEditing = Boolean(editingId);
      const response = await fetch("/api/rebrands", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: editingId || undefined, name: form.name, slug: form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-"), product: "both", loaderTitle: form.loaderTitle || form.name, dllTitle: form.dllTitle || form.name, primaryColor: "#7c8cff", secondaryColor: "#131720", rotateToken: false }) });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Não foi possível salvar o rebrand.");
      resetForm(); await load(); setToast(wasEditing ? "Alterações salvas. O Loader será atualizado automaticamente." : "Rebrand criado. Agora baixe o pacote do Loader.");
    } catch (reason) { setToast(reason instanceof Error ? reason.message : "Não foi possível salvar o rebrand."); }
    finally { setBusy(false); }
  }

  async function downloadLoader(item: Rebrand) {
    if (preview) { setToast("No modo de teste o download fica desativado."); return; }
    setDownloadingId(item.id);
    try {
      const response = await fetch(`/api/reseller/loader?rebrandId=${encodeURIComponent(item.id)}`, { cache: "no-store" });
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new Error(payload.error || "Não foi possível preparar o Loader.");
      }
      const url = URL.createObjectURL(await response.blob());
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `${item.slug || item.name}-loader.zip`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      setToast("Pacote baixado. Mantenha Loader.exe e token.txt juntos.");
    } catch (reason) { setToast(reason instanceof Error ? reason.message : "Não foi possível baixar o Loader."); }
    finally { setDownloadingId(""); }
  }

  async function deleteRebrand(id: string) {
    if (!window.confirm("Excluir este rebrand?")) return;
    const response = await fetch("/api/rebrands", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ id }) });
    const payload = await response.json();
    if (!response.ok) { setToast(payload.error || "Não foi possível excluir."); return; }
    await load(); setToast("Rebrand excluído.");
  }

  const tabs: Array<{ id: ResellerTab; label: string; count: number }> = [
    { id: "rebrands", label: "Rebranding", count: rebrands.length },
    { id: "customers", label: "Clientes", count: data?.clients.length || 0 },
    { id: "licenses", label: "Licenças", count: data?.licenses.length || 0 },
  ];
  const onlineClients = data?.clients.filter((item) => item.online !== false).length || 0;
  const activeLicenses = data?.licenses.filter((item) => !item.licenseExpiry || item.licenseExpiry > Math.floor(Date.now() / 1000)).length || 0;

  return <div className="reseller-shell">
    <header className="reseller-topbar"><div className="logo-lockup"><div className="logo-mark">T</div><div><strong>Titan</strong><span>Control</span></div></div><div className="reseller-user"><span>{user.displayName}</span><small>{preview ? "Prévia · Revendedor" : "Revendedor"}</small><a href="/api/auth/logout">Sair</a></div></header>
    <main className="reseller-main">
      {preview && <div className="preview-banner"><strong>Modo de teste</strong><span>Você está vendo a interface como um revendedor fictício. Nenhum dado real é exibido.</span><a href="/">Voltar ao administrador</a></div>}
      <div className="section-intro reseller-intro"><div><span className="eyebrow accent">PAINEL DO REVENDEDOR</span><h1>Seus produtos, em um só lugar</h1><p>Personalize sua marca e acompanhe apenas os clientes vinculados à sua conta.</p></div><span className="status-pill status-working"><i />Discord conectado</span></div>
      <nav className="reseller-tabs" aria-label="Seções do painel">{tabs.map((tab) => <button className={activeTab === tab.id ? "active" : ""} type="button" key={tab.id} onClick={() => setActiveTab(tab.id)}><span>{tab.label}</span><strong>{tab.count}</strong></button>)}</nav>
      <section className="reseller-summary-bar" aria-label="Resumo da conta"><div><span>Projetos</span><strong>{rebrands.length}</strong><small>marcas configuradas</small></div><div><span>Clientes</span><strong>{data?.clients.length || 0}</strong><small>{onlineClients} online agora</small></div><div><span>Licenças</span><strong>{activeLicenses}</strong><small>ativas no momento</small></div></section>

      {error ? <div className="connection-error"><span>!</span><h2>Não foi possível carregar</h2><p>{error}</p></div> : <>
        {activeTab === "rebrands" && <section className="reseller-rebrand-view">
          <div className="reseller-guide">
            <div><span>01</span><strong>Crie sua marca</strong><small>Defina os nomes que aparecem no Loader e nos produtos.</small></div>
            <div><span>02</span><strong>Baixe uma única vez</strong><small>O pacote já contém o Loader.exe e o token.txt corretos.</small></div>
            <div><span>03</span><strong>Depois, apenas salve</strong><small>Alterações futuras chegam automaticamente, sem baixar outro Loader.</small></div>
          </div>
          <div className="reseller-rebrand-layout">
            <section className="panel reseller-editor"><div className="panel-heading"><div><span className="eyebrow accent">IDENTIDADE</span><h3>{editingId ? "Editar rebrand" : "Criar novo rebrand"}</h3><p>Use “Nome” como a marca principal. Loader e menu podem ter títulos próprios.</p></div></div><form className="reseller-form-stack" onSubmit={saveRebrand}><label>Nome da marca<input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="Ex.: Lunar" /><small>Usado em pastas, configurações, avisos e nomes gerais.</small></label><label>Nome do Loader<input value={form.loaderTitle} onChange={(event) => setForm({ ...form, loaderTitle: event.target.value })} placeholder="Ex.: Lunar Services" /></label><label>Nome do menu<input value={form.dllTitle} onChange={(event) => setForm({ ...form, dllTitle: event.target.value })} placeholder="Ex.: Lunar Menu" /></label><div className="reseller-form-actions"><button className="button primary" type="submit" disabled={busy}>{busy ? "Salvando..." : editingId ? "Salvar alterações" : "Criar rebrand"}</button>{editingId && <button className="button" type="button" onClick={resetForm}>Cancelar</button>}</div></form></section>
            <aside className="reseller-package-note"><div className="package-note-heading"><span className="package-icon">ZIP</span><div><span className="eyebrow">ENTREGA AO CLIENTE</span><strong>Prepare o pacote corretamente</strong></div></div><ol className="package-steps"><li><span>1</span><div><strong>Baixe o Loader</strong><p>Use o botão do rebrand criado para gerar o pacote correto.</p></div></li><li><span>2</span><div><strong>Extraia os dois arquivos</strong><p>Mantenha <code>Loader.exe</code> e <code>token.txt</code> juntos na mesma pasta.</p></div></li><li><span>3</span><div><strong>Envie a pasta completa</strong><p>Não renomeie o <code>token.txt</code> e não execute o Loader dentro do ZIP.</p></div></li></ol><div className="package-auto-note"><span>✓</span><p><strong>Atualização automática</strong>Depois da primeira entrega, basta salvar novos nomes aqui. Não é necessário baixar outro Loader.</p></div></aside>
          </div>
          <section className="panel reseller-projects"><div className="panel-heading"><div><span className="eyebrow">SEUS REBRANDS</span><h3>{rebrands.length ? `${rebrands.length} projeto(s) configurado(s)` : "Nenhum projeto criado"}</h3><p>Baixe, edite ou copie o token de cada marca.</p></div></div>{rebrands.length ? <div className="reseller-brand-list">{rebrands.map((item) => <article className="reseller-brand-card" key={item.id}><div className="brand-card-head"><span className="brand-avatar">{item.name.charAt(0).toUpperCase()}</span><div><strong>{item.name}</strong><small>{item.loaderTitle} · {item.dllTitle}</small></div><span className="brand-ready"><i />Pronto</span></div><div className="brand-token-line"><span>token.txt</span><code>{item.token}</code><button type="button" onClick={() => { navigator.clipboard.writeText(item.token); setToast("Token copiado."); }}>Copiar</button></div><div className="brand-card-actions"><button className="button primary download-loader-button" type="button" onClick={() => downloadLoader(item)} disabled={downloadingId === item.id}>{downloadingId === item.id ? "Preparando..." : "Baixar Loader"}</button><button className="button" type="button" onClick={() => startEdit(item)}>Editar</button><button className="danger-text-button" type="button" onClick={() => deleteRebrand(item.id)}>Excluir</button></div></article>)}</div> : <div className="reseller-empty-brand"><span>R</span><strong>Crie seu primeiro rebrand</strong><p>Depois de salvar, o botão para baixar o Loader aparecerá aqui.</p></div>}</section>
        </section>}

        {activeTab === "customers" && <section className="panel reseller-data-panel"><div className="panel-heading"><div><span className="eyebrow">CLIENTES</span><h3>Clientes vinculados</h3><p>Usuários registrados nos seus rebrands continuam visíveis mesmo offline.</p></div><span className="result-count">{data?.clients.length || 0} cliente(s)</span></div>{data?.clients.length ? <div className="table-wrap"><table className="reseller-customer-table"><thead><tr><th>Cliente</th><th>Discord / computador</th><th>Produto</th><th>Status</th></tr></thead><tbody>{data.clients.map((item) => <tr key={`${item.username}:${item.product}`}><td><div className="user-cell"><span className="avatar">{item.username.slice(0, 2).toUpperCase()}</span><div><strong>{item.username}</strong><small>Cliente vinculado</small></div></div></td><td><strong className="table-primary-text">{item.discordName || "Discord não informado"}</strong><small className="table-secondary-text">{item.computer || "Computador não informado"}</small></td><td><span className={`product-tag ${item.product}`}>{productName(item.product)}</span></td><td><span className={`status-pill reseller-customer-status ${item.online === false ? "status-disabled" : "status-working"}`}><i />{item.online === false ? "Offline" : "Online"}</span></td></tr>)}</tbody></table></div> : <p className="panel-copy">Nenhum cliente vinculado ainda.</p>}</section>}

        {activeTab === "licenses" && <section className="panel reseller-data-panel"><div className="panel-heading"><div><span className="eyebrow">LICENÇAS</span><h3>Validade das licenças</h3><p>Consulte produto, plano e tempo restante.</p></div></div><div className="table-wrap"><table><thead><tr><th>Usuário</th><th>Produto</th><th>Plano</th><th>Validade</th></tr></thead><tbody>{data?.licenses.map((item) => <tr key={`${item.username}:${item.product}`}><td>{item.username}</td><td><span className={`product-tag ${item.product}`}>{productName(item.product)}</span></td><td>{item.subscription || "Indisponível"}</td><td>{expiry(item.licenseExpiry)}</td></tr>)}</tbody></table></div></section>}
      </>}
    </main>
    {toast && <div className="toast">{toast}</div>}
  </div>;
}
