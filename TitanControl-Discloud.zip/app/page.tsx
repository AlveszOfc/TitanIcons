import DashboardClient from "./dashboard-client";
import ResellerClient from "./reseller-client";
import { getSiteUser } from "./discord-auth";

export const dynamic = "force-dynamic";

function LoginPage() {
  return <main className="auth-page"><div className="landing-shell"><section className="landing-hero"><div className="landing-brand"><div className="landing-brand-mark">T</div><div><strong>Titan Services</strong><small>Control center</small></div></div><span className="landing-kicker">OPERAÇÃO CENTRALIZADA</span><h1 className="landing-title">Seu negócio.<br /><span>Sob controle.</span></h1><p className="landing-copy">Um painel direto para gerenciar produtos, clientes, licenças e rebrands sem complicação.</p><div className="landing-points"><div className="landing-point"><span>01</span><div><strong>Visão em tempo real</strong><small>Acompanhe clientes e produtos em um único lugar.</small></div></div><div className="landing-point"><span>02</span><div><strong>Permissões separadas</strong><small>Administrador e revendedores veem somente o necessário.</small></div></div><div className="landing-point"><span>03</span><div><strong>Arquivos protegidos</strong><small>Distribuição privada e controlada das versões.</small></div></div></div></section><div className="auth-card"><div className="auth-logo">T</div><span className="eyebrow">ACESSO AO PAINEL</span><h1>Entrar</h1><p>Use sua conta Discord autorizada para continuar.</p><a className="button primary auth-button" href="/api/auth/discord/start"><span className="discord-mark">●</span>Continuar com Discord<span className="button-arrow">→</span></a><div className="auth-security"><span>✓</span><div><strong>Ambiente protegido</strong><small>Autenticação segura via Discord.</small></div></div></div></div></main>;
}

export default async function Home({ searchParams }: { searchParams?: Promise<{ preview?: string }> }) {
  const user = await getSiteUser();
  if (!user) return <LoginPage />;
  const params = searchParams ? await searchParams : {};
  if (user.role === "admin" && params.preview === "reseller") {
    return <ResellerClient user={{ ...user, displayName: "Revendedor de teste", role: "reseller" }} preview />;
  }
  return user.role === "admin" ? <DashboardClient user={user} /> : <ResellerClient user={user} />;
}
