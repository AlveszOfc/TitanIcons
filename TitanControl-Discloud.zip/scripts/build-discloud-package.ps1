$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
$stage = Join-Path $projectRoot ".discloud-package-stage"
$archive = Join-Path $projectRoot "TitanControl-Discloud.zip"
$resolvedRoot = [System.IO.Path]::GetFullPath($projectRoot).TrimEnd('\') + '\'
$resolvedStage = [System.IO.Path]::GetFullPath($stage).TrimEnd('\') + '\'

if (-not $resolvedStage.StartsWith($resolvedRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
  throw "A pasta temporaria saiu do projeto. Empacotamento cancelado."
}

if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
if (Test-Path -LiteralPath $archive) { Remove-Item -LiteralPath $archive -Force }
New-Item -ItemType Directory -Path $stage | Out-Null

$items = @(
  "app",
  "public",
  "types",
  "scripts",
  "sql",
  "discloud.config",
  "discloud.env.example",
  "package.json",
  "package-lock.json",
  "next.config.ts",
  "postcss.config.mjs",
  "eslint.config.mjs",
  "tsconfig.json",
  "server.mjs"
)

foreach ($item in $items) {
  $source = Join-Path $projectRoot $item
  if (-not (Test-Path -LiteralPath $source)) { throw "Arquivo obrigatorio ausente: $item" }
  Copy-Item -LiteralPath $source -Destination $stage -Recurse -Force
}

$previewDirectory = Join-Path $stage "app\_sites-preview"
if (Test-Path -LiteralPath $previewDirectory) { Remove-Item -LiteralPath $previewDirectory -Recurse -Force }

Add-Type -AssemblyName System.IO.Compression
$stream = [System.IO.File]::Open($archive, [System.IO.FileMode]::CreateNew)
$zip = New-Object System.IO.Compression.ZipArchive($stream, [System.IO.Compression.ZipArchiveMode]::Create)
try {
  Get-ChildItem -LiteralPath $stage -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($stage.Length).TrimStart('\').Replace('\', '/')
    $entry = $zip.CreateEntry($relative, [System.IO.Compression.CompressionLevel]::Optimal)
    $entryStream = $entry.Open()
    $fileStream = [System.IO.File]::OpenRead($_.FullName)
    try { $fileStream.CopyTo($entryStream) } finally { $fileStream.Dispose(); $entryStream.Dispose() }
  }
} finally {
  $zip.Dispose()
  $stream.Dispose()
}
Remove-Item -LiteralPath $stage -Recurse -Force
Write-Output $archive
