import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import pg from "pg";

const connectionString = process.env.DATABASE_URL?.trim();
if (!connectionString) {
  console.error("[Titan Control] DATABASE_URL nao foi configurada.");
  process.exit(1);
}

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const schema = await readFile(join(root, "sql", "postgres-schema.sql"), "utf8");
const useSsl = process.env.DATABASE_SSL?.trim().toLowerCase() === "true";
const pool = new pg.Pool({ connectionString, ssl: useSsl ? { rejectUnauthorized: false } : undefined, max: 2 });

let lastError;
for (let attempt = 1; attempt <= 12; attempt += 1) {
  try {
    await pool.query(schema);
    await pool.end();
    console.log("[Titan Control] Banco PostgreSQL pronto.");
    process.exit(0);
  } catch (error) {
    lastError = error;
    if (attempt < 12) await new Promise((resolve) => setTimeout(resolve, 2500));
  }
}

await pool.end().catch(() => undefined);
console.error("[Titan Control] Nao foi possivel preparar o banco:", lastError instanceof Error ? lastError.message : lastError);
process.exit(1);
