CREATE TABLE IF NOT EXISTS rebrands (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  product TEXT NOT NULL DEFAULT 'both',
  primary_color TEXT NOT NULL DEFAULT '#7c8cff',
  secondary_color TEXT NOT NULL DEFAULT '#131720',
  loader_title TEXT NOT NULL DEFAULT '',
  dll_title TEXT NOT NULL DEFAULT '',
  logo_url TEXT NOT NULL DEFAULT '',
  token_hash TEXT NOT NULL UNIQUE,
  token TEXT NOT NULL DEFAULT '',
  version INTEGER NOT NULL DEFAULT 1,
  created_by TEXT NOT NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS artifacts (
  id TEXT PRIMARY KEY,
  rebrand_id TEXT NOT NULL,
  object_key TEXT NOT NULL UNIQUE,
  file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  size BIGINT NOT NULL,
  created_by TEXT NOT NULL,
  created_at BIGINT NOT NULL,
  chunked INTEGER NOT NULL DEFAULT 0,
  part_count INTEGER NOT NULL DEFAULT 1,
  product TEXT NOT NULL DEFAULT 'full'
);

CREATE TABLE IF NOT EXISTS artifact_uploads (
  id TEXT PRIMARY KEY,
  object_key TEXT NOT NULL UNIQUE,
  upload_id TEXT NOT NULL,
  rebrand_id TEXT NOT NULL,
  file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  size BIGINT NOT NULL,
  created_by TEXT NOT NULL,
  created_at BIGINT NOT NULL,
  product TEXT NOT NULL DEFAULT 'full'
);

CREATE TABLE IF NOT EXISTS artifact_links (
  token_hash TEXT PRIMARY KEY,
  artifact_id TEXT NOT NULL,
  created_by TEXT NOT NULL,
  expires_at BIGINT NOT NULL,
  downloads INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS artifact_authorization_limits (
  bucket TEXT PRIMARY KEY,
  window_start BIGINT NOT NULL,
  requests INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS artifact_objects (
  object_key TEXT PRIMARY KEY,
  data BYTEA NOT NULL,
  content_type TEXT NOT NULL DEFAULT 'application/octet-stream',
  size BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS rebrand_memberships (
  id TEXT PRIMARY KEY,
  rebrand_id TEXT NOT NULL,
  username TEXT NOT NULL,
  username_key TEXT NOT NULL,
  product TEXT NOT NULL,
  subscription TEXT NOT NULL DEFAULT '',
  license_expiry BIGINT NOT NULL DEFAULT 0,
  hwid TEXT NOT NULL DEFAULT '',
  first_seen BIGINT NOT NULL,
  last_seen BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS web_users (
  discord_id TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  display_name TEXT NOT NULL,
  avatar TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'pending',
  active INTEGER NOT NULL DEFAULT 1,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  last_login BIGINT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS web_sessions (
  token_hash TEXT PRIMARY KEY,
  discord_id TEXT NOT NULL,
  expires_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL
);

ALTER TABLE rebrands ADD COLUMN IF NOT EXISTS token TEXT NOT NULL DEFAULT '';
ALTER TABLE artifacts ADD COLUMN IF NOT EXISTS chunked INTEGER NOT NULL DEFAULT 0;
ALTER TABLE artifacts ADD COLUMN IF NOT EXISTS part_count INTEGER NOT NULL DEFAULT 1;
ALTER TABLE artifacts ADD COLUMN IF NOT EXISTS product TEXT NOT NULL DEFAULT 'full';
ALTER TABLE artifact_uploads ADD COLUMN IF NOT EXISTS product TEXT NOT NULL DEFAULT 'full';

CREATE UNIQUE INDEX IF NOT EXISTS rebrand_memberships_account_unique ON rebrand_memberships(product, username_key);
CREATE INDEX IF NOT EXISTS rebrand_memberships_rebrand_idx ON rebrand_memberships(rebrand_id);
CREATE INDEX IF NOT EXISTS artifacts_rebrand_product_idx ON artifacts(rebrand_id, product, created_at DESC);
CREATE INDEX IF NOT EXISTS artifact_links_expiry_idx ON artifact_links(expires_at);
CREATE INDEX IF NOT EXISTS web_sessions_discord_idx ON web_sessions(discord_id);
