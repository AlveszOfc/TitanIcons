import { createServer } from "node:http";
import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";
import next from "next";

const hostname = "0.0.0.0";
const port = Number(process.env.PORT) || 8080;

if (!existsSync("build/BUILD_ID")) {
  console.log("[Titan Control] Build de producao ausente. Preparando o site...");
  const build = spawnSync(process.execPath, ["node_modules/next/dist/bin/next", "build"], {
    stdio: "inherit",
    env: process.env,
  });

  if (build.status !== 0 || !existsSync("build/BUILD_ID")) {
    console.error("[Titan Control] Nao foi possivel gerar o build de producao.");
    process.exit(build.status || 1);
  }
}

if (process.env.DATABASE_URL?.trim()) {
  console.log("[Titan Control] Preparando banco de dados...");
  const database = spawnSync(process.execPath, ["scripts/bootstrap-database.mjs"], {
    stdio: "inherit",
    env: process.env,
  });

  if (database.status !== 0) {
    console.error("[Titan Control] O banco de dados ainda nao esta disponivel.");
    process.exit(database.status || 1);
  }
} else {
  console.warn("[Titan Control] DATABASE_URL ainda nao foi configurada.");
}

const app = next({ dev: false, hostname, port });
const handle = app.getRequestHandler();

await app.prepare();

const server = createServer((request, response) => handle(request, response));
server.listen(port, hostname, () => {
  console.log(`[Titan Control] Online em http://${hostname}:${port}`);
});

function shutdown() {
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 10000).unref();
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
